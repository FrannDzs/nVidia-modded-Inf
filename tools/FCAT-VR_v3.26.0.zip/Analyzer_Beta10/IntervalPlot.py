import logging

from functools import partial
import pyqtgraph as pg
import PyQt5.QtGui as qtg
from PyQt5.QtCore import pyqtSignal, pyqtSlot

from LegendItem import LegendItem

class IntervalPlot(pg.PlotItem):

    def __init__(self, *args, ftp=None, curve=None, **kwargs):
        super(IntervalPlot, self).__init__(*args, **kwargs)
    
        self.ds = ftp.selectedDataset
        self.pen = pg.mkPen('y')
        
        self.setXLink(ftp)
        self.setLimits(yMax=100)
        self.setLimits(yMin=0)
        self.setLimits(xMin=0)
        self.setRange(yRange =[0,100])
        self.setLabel(axis='bottom', text = 'Time (s)')
        
        self.setMenuEnabled(False)

        self.setTitle("Intervals", size="18pt")
        self.setLabel(axis='left', text = 'Frames Per Second')

        # Set up frametype brushes
        rBrush = qtg.QBrush(qtg.QColor(0xff, 0x00, 0x00, 200))
        yBrush = qtg.QBrush(qtg.QColor(0xff, 0xff, 0x00, 200))
        gBrush = qtg.QBrush(qtg.QColor(0x00, 0xff, 0x00, 200))

        # Curves for the inteval plot
        self.curveRT = pg.PlotCurveItem(brush=gBrush,pen=qtg.QPen(qtg.QColor(0, 0, 0, 0)),  name = 'New Frames')
        self.curveRT.setFillLevel(0)
        self.curveST = pg.PlotCurveItem(brush=yBrush, pen=qtg.QPen(qtg.QColor(0, 0, 0, 0)), clickable=True, name = 'Synth Frames')
        self.curveDT = pg.PlotCurveItem(brush=rBrush, pen=qtg.QPen(qtg.QColor(0, 0, 0, 0)), clickable=True, name = 'Dropped Frames')
        self.fillSR = pg.FillBetweenItem(self.curveST, self.curveRT, brush=yBrush)
        self.fillDS = pg.FillBetweenItem(self.curveDT, self.curveST, brush=rBrush)

        self.addItem(self.curveRT)
        self.addItem(self.curveST)
        self.addItem(self.curveDT)
        self.addItem(self.fillSR)
        self.addItem(self.fillDS)
     
        # Adding in a legend        
        self.legend = LegendItem()
        self.legend.setParentItem(self)
        self.legend.anchor((1,0), (1,0), (-10, 40))

    # Draw a plot of the selected datasets' interval
    def plotIntervals(self):

        if not self.listDataItems():
            self.addItem(self.curveRT)
            self.addItem(self.curveST)
            self.addItem(self.curveDT)
            self.addItem(self.fillSR)
            self.addItem(self.fillDS)
      
        # Add to the legend
        self.legend.addItem(self.curveRT, "New Frames", "b")
        self.legend.addItem(self.curveST, "Synth Frames", "b")
        self.legend.addItem(self.curveDT, "Dropped Frames", "b")
        self.refreshData()

    def removeCurves(self):
        self.removeItem(self.curveRT)
        self.removeItem(self.curveST)
        self.removeItem(self.curveDT)
        self.removeItem(self.fillSR)
        self.removeItem(self.fillDS)
        #self.clear()
        self.legend.reset()

    def refreshData(self):
        self.data = self.ds.smoothedIntervalData()
        self.name = self.ds.name()
        self.setTitle(self.name)

        self.curveRT.setData(x=self.data[:,0], y=self.data[:,1])
        self.curveST.setData(x=self.data[:,0], y=(self.data[:,2] + self.data[:,1]))
        self.curveDT.setData(x=self.data[:,0], y=(self.data[:,3] + self.data[:,2] + self.data[:,1]))
