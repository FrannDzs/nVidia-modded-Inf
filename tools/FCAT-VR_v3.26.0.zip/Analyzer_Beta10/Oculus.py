import logging
import math

from PyQt5.QtCore import QObject, Qt
from Structs import *
from PyQt5.QtCore import pyqtSignal, pyqtSlot

class Oculus (QObject):
    
    loaderMsg = pyqtSignal(str,int)


    def __init__(self, *args, **kwargs):
        super(Oculus, self).__init__(*args, **kwargs)
    
        def loaderMsessageHandler(str, type=0):
            if type == 0:
                logging.info(str)
            if type == 1:
                logging.warn(str)
            if type == 2:
                logging.error(str)

        self.loaderMsg.connect(loaderMsessageHandler)

    def parseFile(self, reader, appFrames, intervals):
        
        startTime = float('NaN')

        # Process all the rows in the reader
        for row in reader:

            # Grab the first valid Game start for the base offset
            if math.isnan(startTime):
                 startTime = float_or_na(row[r'Game Start (ms)'])
                
            if  math.isnan(startTime):
                continue
            
            # Get frame and interval data
            (frame, intv) = self.parseLine (row, startTime)

            # Detect if this is same app frame  - If it is then don't add a new frame
            if len (appFrames):
                if not (frame.frameNumber ==  appFrames[-1].frameNumber):
                    appFrames.append(frame)
                    
                # check for sequential frame numbers
                if not (frame.frameNumber !=  appFrames[-1].frameNumber -1):
                    self.loaderMsg.emit('Frame Skipped at %d' % frame.frameNumber) 

            else:
                appFrames.append(frame)

            # Save interval info
            intervals.append(intv)


    # Parse one line line of the input
    def parseLine(self, row, startTime):

        f = appFrame()
        intv = Interval()

        # timings for an appFrame
        f.frameNumber   = int_or_na(row[r'Frame Index'])
        f.queueAhead    = float_or_na(row[r'Queue Ahead (ms)'])

        f.CPUStart      = float_or_na(row[r'Game Start (ms)']) - startTime
        f.CPUEnd        = float_or_na(row[r'Game Complete CPU (ms)']) - startTime
            
        # Sad that we dont have a trimestamp for GPU render start
        f.GPUStart      = f.CPUEnd 
        f.GPUEnd        = float_or_na(row[r'Game Complete GPU (ms)'])  - startTime

        # Calculated frametime
        f.frameTime     = f.GPUEnd - f.CPUStart
        f.time          = f.CPUStart / 1000

        # Timings related to an interval
        intv.warpStart  = (float_or_na(row[r'Runtime Sample (ms)']) - startTime) /1000
        intv.warpEnd    = (float_or_na(row[r'Runtime Complete (ms)']) - startTime) /1000
        intv.warpMiss   = int_or_na(row[r'Warp Miss'])
        intv.appMiss    = int_or_na(row[r'App Miss'])

        # In some Occulus runs no ASW...so default to 0
        intv.aswOn      = int_or_na(row.get(r'ASW Status', 0))
            
        # Check for vsync - if present use it
        vs              = float_or_na(row[r'VSync (ms)'])
        if vs:
            intv.time   = (vs - startTime) / 1000
        else:
            intv.time   = f.time
 
        return(f, intv)
        