import logging
import os
import re
import time

from PyQt5.QtCore import (QAbstractTableModel, QObject, QModelIndex,
                          Qt, QThread, QVariant, pyqtSignal, pyqtSlot)

from DataFile import DataFile, FileState
from enum import Enum


class Model(QAbstractTableModel):

    startThread = pyqtSignal()
    rescanDatafiles = pyqtSignal()


    header_labels = [
        'State', 'Type', 'ID1', 'ID2', 'Other',
        'Delivered\nFPS', 'Unconstrained\nFPS', 'Refresh\nIntervals', 'New\nFrames',
        'Dropped\nFrames', 'Dropped\nPercent','Synth\nFrames', 'Synth\nPercent', 'Warp\nMiss', 'Avg\nFrametime', '50th', '90th', '95th', '99th', 'Worst', 'Test\nTime',  'Datfile',  'Fullpath']

    drop_header_labels = [
        'State', 'Type', 'ID1', 'ID2', 'Other',
        'Delivered FPS', 'Unconstrained FPS', 'Refresh Intervals', 'New Frames',
        'Dropped Frames', 'Dropped Percent', 'Synth Frames', 'Synth Percent', 'Warp Miss', 'Avg Frametime', '50th', '90th', '95th', '99th','Worst','Test Time',  'Datfile',  'Fullpath']

    def __init__(self, *args, **kwargs):
        super(Model,self).__init__(*args, **kwargs) 
        self.dataFiles = []
    
    def addFile(self, df):
        logging.info ('Adding Datafile %s' % df.fullpath)
        existingRows = len(self.dataFiles)

        self.layoutAboutToBeChanged.emit()
        self.beginInsertRows(QModelIndex(), existingRows, existingRows+1)
        self.dataFiles.append(df)
        self.endInsertRows()
        self.layoutChanged.emit()


    # return the number of columns of the parent if present
    def columnCount(self, index):
        return len(self.header_labels)

    def rowCount(self, parentIndex=None):
        r = len(self.dataFiles)
        return r


    # Access the underlyying data structures to get data back.
    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return QVariant()

        row = index.row()
        col= index.column()

        # Do some consistency checking
        if row >= len (self.dataFiles):
            raise ValueError('Model.data : bad row index')

        # Return a pointer to the datafile object 
        if role == Qt.UserRole:
            return self.dataFiles[row]

        if (role == Qt.DisplayRole) or (role == Qt.EditRole):
            return self.dataFiles[row].readData(col)

        # Align Data in the tableview
        elif role == Qt.TextAlignmentRole:
            return (Qt.AlignVCenter | Qt.AlignLeft)

        return

    def setData(self, index, value, role=Qt.EditRole):
        col = index.column()
        row = index.row()

        # Set the data element
        if (role == Qt.EditRole):
            self.dataFiles[row].update(col, value)
            self.dataChanged.emit(index, index, ())

        #elif role == Qt.CheckStateRole:
        #    self.dataFiles[row].checked = value
        #    self.dataChanged.emit(index, index, ())

        return True

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and orientation == Qt.Horizontal:
            return self.header_labels[section]
        return QAbstractTableModel.headerData(self, section, orientation, role)

    def flags(self, index):
        col = index.column()

        flag = Qt.ItemIsDropEnabled |  Qt.ItemIsEnabled | Qt.ItemIsSelectable 

        # editable columns
        if col == 2 or col == 3 or col == 4:
            flag = flag | Qt.ItemIsEditable

        return flag

    def filterChanged(self, string):
          return

    def recalcStats(self):
        for dft in self.dataFiles:
            dft.calcStats()

    def clear(self):
        logging.info('Cleared Model')
        self.beginResetModel()
        self.dataFiles = []
        self.endResetModel()
