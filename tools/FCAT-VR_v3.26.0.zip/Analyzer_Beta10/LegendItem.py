import pyqtgraph as pg

from pyqtgraph import GraphicsWidget, ScatterPlotItem, Point, PlotDataItem, GraphicsWidgetAnchor
from pyqtgraph import ScatterPlotItem

from LabelItem import LabelItem

from PyQt5 import QtCore, QtGui
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QBrush

import pyqtgraph.functions as fn

__all__ = ['LegendItem']

class LegendItem(GraphicsWidget, GraphicsWidgetAnchor):
    def __init__(self, size=None, offset=None):
        GraphicsWidget.__init__(self)
        GraphicsWidgetAnchor.__init__(self)
        self.setFlag(self.ItemIgnoresTransformations)
        self.layout = QtGui.QGraphicsGridLayout()

        self.setLayout(self.layout)
        self.items = []
        self.reset(size, offset)

    def setParentItem(self, p):
        ret = GraphicsWidget.setParentItem(self, p)
        if self.offset is not None:
            offset = Point(self.offset)
            anchorx = 1 if offset[0] <= 0 else 0
            anchory = 1 if offset[1] <= 0 else 0
            anchor = (anchorx, anchory)
            self.anchor(itemPos=anchor, parentPos=anchor, offset=offset)
        return ret
        
    def addItem(self, item, name, c):
        
        label = LabelItem(name, justify='right')
        if isinstance(item, ItemSample):
            sample = item
        else:
            sample = ItemSample(item)        

        row = self.layout.rowCount()
        self.items.append((sample, label))
        self.layout.addItem(sample, row, 0)
        self.layout.addItem(label, row, 1)
        self.layout.setRowAlignment(row, Qt.AlignVCenter)
        self.updateSize()
    

    def reset(self, size=None, offset=None):
        
        # Clear all items from the layout
        self.removeAllItem()

        self.items = []
        self.size = size
        self.offset = offset
        if size is not None:
            self.setGeometry(QtCore.QRectF(0, 0, self.size[0], self.size[1]))

        self.updateSize()

    def removeAllItem(self):
        for sample, label in self.items:
            self.layout.removeItem(sample)          # remove from layout
            sample.close()                          # remove from drawing
            self.layout.removeItem(label)
            label.close()

    def updateSize(self):
        #if self.size is not None:
        #    return
            
        height = 0
        width = 0
        #print("----Size checks---")
        for sample, label in self.items:
            #print ("%s" % label.text)

            lw = label.width()
            lh = label.height()

            # Sample width and height seems odd
            sw = sample.width()
            sh = sample.height()
            sw = 40
            sh = 20

            #print ("SW: %d SH:%d  LW: %d LH: %d" % (sw, sh, lw, lh))

            height += max(sh, lh)
            width   = max(width, (sw + lw ))
            #print ("Current Label Geo W: %d H:%d" % (width, height))

        self.setGeometry(0, 0, width,  height)
    
    def boundingRect(self):
        return QtCore.QRectF(0, 0, self.width(), self.height())

    # Set the font in a legend
    def setFont(self, fs, color):
        #print ("set to %s %s" % (fs, color))
        for sample, label in self.items:
            label.setAttr ("size", fs)
            label.setAttr ("color", color)
            label.setText (label.text)
        
        self.updateSize()
            
    def paint(self, p, *args):
        p.setPen(fn.mkPen(255,255,255,255))
        p.setBrush(fn.mkBrush(255,255,255,80))
        #p.drawRect(self.boundingRect())

    def hoverEvent(self, ev):
        ev.acceptDrags(QtCore.Qt.LeftButton)
        
    def mouseDragEvent(self, ev):
        if ev.button() == QtCore.Qt.LeftButton:
            dpos = ev.pos() - ev.lastPos()
            self.autoAnchor(self.pos() + dpos)
        
class ItemSample(GraphicsWidget):
    ## Todo: make this more generic; let each item decide how it should be represented.
    def __init__(self, item,  *args, **kwargs):
        super(ItemSample, self).__init__(*args, **kwargs) 
        self.item = item
        print ("New Sample created")
    
    def boundingRect(self):
        return QtCore.QRectF(0, 0, 20, 20)
        
    def paint(self, p, *args):
        opts = self.item.opts
        pen = opts['pen']
        color = pen.color()
        
        if 'brush' in opts:
            brush = opts['brush']
            if brush:
                color = brush.color()

        p.setBrush(QBrush(color))
        p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(4,4), QtCore.QPointF(16,4), QtCore.QPointF(16,16), QtCore.QPointF(4,16) ]    ))
        
        

        
        
        
        
