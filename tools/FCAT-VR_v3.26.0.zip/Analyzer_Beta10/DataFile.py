import csv
import logging
import time
from random import randint

from PyQt5.QtCore import QObject, Qt
import numpy as np
import math

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import pyqtSignal, pyqtSlot


from Structs import *
from Oculus import *
from Vive import *
from MS_MR import *
from HWCap import *
from FRAPS import *
from OCAT import *


#
# Datafile.py = represents a single input data set
#


class DataFile(QObject):  

    
    initCount = 0

    # Signal for threaded process to communicate back to main thread
    loaderMsg = pyqtSignal(str,int)
    heartBeat = pyqtSignal()

    def __init__(self, *args, inData, **kwargs):
        super(DataFile, self).__init__(*args, **kwargs)
          
        self.setObjectName( 'Datafile' + str(DataFile.initCount))
        DataFile.initCount = DataFile.initCount +1

        def loaderMsessageHandler(str, type=0):
            if type == 0:
                logging.info(str)
            if type == 1:
                logging.warn(str)
            if type == 2:
                logging.error(str)

        self.loaderMsg.connect(loaderMsessageHandler)

        # File is not yet valid
        self.type = FileType.Unknown
        self.state = FileState.INIT
        self.deliveredFPS = ""
        self.unconstrainedFPS = ""
        self.intvs =""
        self.delivered =""
        self.drops =""
        self.dropsPercent =""
        self.synth =""
        self.synthPercent =""
        self.warpMiss =""
        self.avgFrameTime =""
        self.p50th =""
        self.p90th =""
        self.p95th =""
        self.p99th =""
        self.worst =""
        self.testTime =""
        self.selected = False

        # Temp defaults for  persistent plot attributes
        self.startTime = 0
        self.stopTime = 100000
        self.offset = 0
        self.pen = None

        # Each Datafile has some plotting characteristics
        self.plotOptions = {}

        if inData:
            if inData[0]:
                self.fullpath   = inData[0]
                self.d1         = inData[1]
                self.d2         = inData[2]
                self.rest       = inData[3]
                self.file       = inData[4]
        
    def calcStats(self):
        if self.state == FileState.VALID:
            self.calculateFrameStats()
            self.calculateIntervalStats()

    # Update a data element
    def update (self, col, val):
        if col == 2:
            self.d1         = val
        if col == 3:
            self.d2         = val
        if col == 4:
            self.rest       = val

    # return the correct data element
    def readData(self, col):
        vc = [
            self.state,
            self.type,
            self.d1, 
            self.d2,
            self.rest
            ]


        if self.state == FileState.VALID:
            vc.extend([
                self.deliveredFPS,
                self.unconstrainedFPS,
                self.intvs,
                self.delivered,
                self.drops,
                self.dropsPercent,
                self.synth,
                self.synthPercent,
                self.warpMiss,
                self.avgFrameTime,
                self.p50th, 
                self.p90th,
                self.p95th,
                self.p99th,
                self.worst,

                self.testTime])
        else:
            vc.extend([
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                ""])

        vc.extend([
            self.file,
            self.fullpath])

        return vc[col]

    def readDataAll(self, size):
        d = []
        for i in range (0,size):
            d.append(self.readData(i))
        return(d)

    # Retrun a name for the dataset
    def name (self):
        n = '%s - %s - %s' % (self.d1, self.d2, self.rest)
        return (n)

    # Retrun a name for the dataset
    def select (self):
        self.selected = True

    # Retrun a name for the dataset
    def deselect (self):
        self.selected = False

    # Returns a list of frametimes
    def frameTimes(self):

        # Apply the offset to shift the times.
        offsetArr = self.numpyframetimes + [self.offset,0] 

        # Apply the start and stop to prune elements
        ft = offsetArr[(self.stopTime > offsetArr[:,0]) & (offsetArr[:,0] > self.startTime) ]

        return ft

    # Returns a list of frametimes
    def intervalData(self):

        # Apply the offset to shift the times.
        it = []

        if self.numpyIntervalData.any() :
            offsetArr = self.numpyIntervalData + [self.offset,0,0,0,0] 

			# Apply the start and stop to prune elements
            it = offsetArr[(self.stopTime > offsetArr[:,0]) & (offsetArr[:,0] > self.startTime) ]

        return it


    def smoothedIntervalData(self):
        
        # Apply the offset to shift the times.
        offsetArr = self.numpyIntervalData + [self.offset,0,0,0,0] 

        # Apply the start and stop to prune elements
        it = offsetArr[(self.stopTime > offsetArr[:,0]) & (offsetArr[:,0] > self.startTime) ]

        # count the events over n intervals
        normalizeTo = 90
        window = 4

        # Get an average
        a = self.average(it, window) 
        
        # Normalize it
        a = a * [1, normalizeTo/window,  normalizeTo/window,  normalizeTo/window, normalizeTo/window]       
        
        return a

    def average(self, arr, n):
                
        try:
            # Last Sample
            end =  n * int(len(arr)/n)
            rs = arr[:end].reshape(-1, n, 5)

            av = np.mean(rs,1) 
            win = av * [1,n,n,n, n]

        except:
            logging.error('Dataset too small to analyize : %s' % self.fullpath) 
            win =  [[1,n,n,n, n]]

        return win
        
    def calculateFrameStats(self):
        dat =  self.frameTimes()
        (frames, els) = dat.shape     
        
        # Ignore NaN's
        mdat = np.ma.masked_array(dat ,np.isnan(dat))
        (t, avgFrameTime) = np.mean(mdat,axis=0)

        # Check division
        if avgFrameTime:
            avgFPS = 1000/avgFrameTime
        else:
            avgFPS = 0

        (endTime, ft) = self.frameTimes()[-1]
        (startTime, ft) = self.frameTimes()[0]
        
        self.avgFrameTime       = avgFrameTime
        self.frames             = frames
        self.testTime           = endTime - startTime
        self.unconstrainedFPS   = avgFPS

        # numpy calculated percentiles!
        (t, self.p50th) = np.percentile(mdat,50,axis=0)
        (t, self.p90th) = np.percentile(mdat,90,axis=0)
        (t, self.p95th) = np.percentile(mdat,95,axis=0)
        (t, self.p99th) = np.percentile(mdat,99,axis=0)
        (t, self.worst) = np.percentile(mdat,100,axis=0)


    def calculateIntervalStats(self):
        intv  = 0
        drops = 0
        synths  = 0
        warps = 0
        deliveredFPS = 0
        delivered = 0

        if self.intervalData:
            # Use interval data to calculate stats
            for (t, real, synth, drop, warpMiss) in self.intervalData():
                intv = intv + 1 
                drops  = drops  + drop
                synths = synths + synth
                warps  = warps  + warpMiss

            (endTime, real, synth, drop, warpMiss)  = self.intervalData()[-1]
            (startTime, real, synth, drop, warpMiss)  = self.intervalData()[0]

            testTime = endTime - startTime

            delivered = (intv - drops - synths)
            deliveredFPS = delivered / testTime

        # Set the global results
        self.intvs          = intv
        self.delivered      = delivered
        self.drops          = drops
        self.dropsPercent   = drops/intv

        self.warpMiss       = warps
        self.synth          = synths
        self.synthPercent   = synths/intv

        self.deliveredFPS   = deliveredFPS


    def loadFile(self):

        # Skip if already loaded
        if self.state == FileState.VALID:
            return
        # Start the load
        #self.loaderMsg.emit ('Loading started : %s' % self.fullpath, 0)
        self.state = FileState.LOADING 
        
        # Drop old data
        self.appFrames = []
        self.numpyframetimes = []
        self.intervals = []
        
        with open(self.fullpath, 'r') as f:

            # This is looking for a csv header            
            try:
                hl = next(f)
            except:
                self.state = FileState.INVALID
                return  

            # Some files are not ',' seperated.....
            header = [h.strip() for h in hl.split(',')]
            
            # If not CVS...then header must be [] seperated.
            tabBased = False
            if len (header) < 2:
                header = [h.strip('[]\n') for h in hl.split('\t')]
                tabBased = True

            # Some files are tab sepereated and some are commas
            if not tabBased:
                d_reader = csv.DictReader(f, fieldnames=header)
            else:
                d_reader = csv.DictReader(f, delimiter='\t', fieldnames=header)

            header = d_reader.fieldnames
            type = self.getType (header)
            
            # Save globally
            self.type = type

            if (type == FileType.Unknown):
                self.loaderMsg.emit('Unknown File type  %s' % self.fullpath, 1) 
                self.state = FileState.INVALID
                return

            # Grab a parser based on type
            parser = None    
            if type == FileType.VR_SW_OCC:
                parser = Oculus()
            elif type == FileType.VR_SW_VIVE:
                parser = Vive()
            elif type == FileType.VR_SW_MS_MR:
                parser = MS_MR()
            elif type == FileType.VR_HW:
                parser = VR_HWCap()
            elif type == FileType.HW:
                parser = HWCap()
            elif type == FileType.FRAPS:
                parser = FRAPS()
            elif type == FileType.OCAT:
                parser = OCAT()
            else:
                return

            # Process file
            parser.parseFile(d_reader, self.appFrames, self.intervals)

            # Generate the frametime array
            times = []
            for f in self.appFrames:
                times.append([f.time, f.frameTime])
            
            # Convert to a numpy array and delete NAs
            self.numpyframetimes = np.array(times).astype(np.float)   
            where_are_NaNs = np.isnan(self.numpyframetimes)
            self.numpyframetimes[where_are_NaNs] = 0

            sz = self.numpyframetimes.shape

            # Generate the Interval Data array
            intv = []
            for i in self.intervals:

                synth = 0
                drop = 0
                real = 1
    
                if i.appMiss:                
                    real = 0
                    if i.aswOn:
                        synth = 1
                    else:
                        drop = 1

                # save a calculated interval record            
                rec = (i.time, real, synth, drop, i.warpMiss)             
                intv.append(rec)
            
            # Completed the load
            self.numpyIntervalData = np.array(intv).astype(np.float)   
            where_are_NaNs = np.isnan(self.numpyIntervalData)
            self.numpyIntervalData[where_are_NaNs] = 0

        # Update messages and calculate stats
        #self.loaderMsg.emit ('Loading complete : %s  loaded %d lines' % (self.fullpath, sz[0]), 0)
        self.state = FileState.VALID

    def getType(self, header):
        # Look for different header combinations to figure out the type

        if r"HolographicFrameID" in header:
            return FileType.VR_SW_MS_MR
        
        got = True
        #for h in ['App Miss', 'Warp Miss', 'ASW Status']:
        for h in ['App Miss', 'Warp Miss']:
            if not h in header:
                got = False
        if got:
            return FileType.VR_SW_OCC

        if r"Total GPU render time (ms)" in header:
            return FileType.VR_SW_VIVE

        # Finding the VR HW filetype
        got = True
        for h in ['frame', 'time (ms)', 'app color', 'warp color']:
            if not h in header:
                got = False
        if got:
            return FileType.VR_HW


        # Finding the HW CAP filetype
        got = True
        for h in ['frame', 'time (ms)', 'color']:
            if not h in header:
                got = False
        if got:
            return FileType.HW



        # Look for a FRAPs Frametimne file
        got = True
        for h in ['Frame', 'Time (ms)']:
            if not h in header:
                got = False
        if got:
            return FileType.FRAPS

        # Look for a OCAT Frametimne file
        got = True
        for h in ['SwapChainAddress']:
            if not h in header:
                got = False
        if got:
            return FileType.OCAT

        return FileType.Unknown

