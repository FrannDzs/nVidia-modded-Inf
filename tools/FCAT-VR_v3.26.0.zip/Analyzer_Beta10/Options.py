
import logging
import re

from functools import partial
from PlotItems import CrossHair
from LegendItem import LegendItem

import pyqtgraph as pg
from PyQt5.QtCore import pyqtSignal, pyqtSlot
from PyQt5.QtCore import Qt, QPoint
import PyQt5.QtGui as qtg 


class Options (object):
    
    def getOption(self, optionName):
        optionValue = "42"
        return(optionValue)

    def setOption


