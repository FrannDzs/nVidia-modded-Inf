from enum import Enum

class FileType(Enum):
    Unknown     = 0
    FRAPS       = 1
    HW          = 2
    FLIP_DATA   = 3
    VR_SW_VIVE  = 4
    VR_SW_OCC   = 5
    VR_SW_MS_MR  = 6
    VR_HW       = 7
    OCAT        = 8

class FileState(Enum):
    INIT        = 0
    LOADING     = 1
    INVALID     = 2
    VALID       = 3

# Class to describe a single app frame
class appFrame():
    def __init__(self):
        self.frameNumber    = 0
        self.appColor       = 0
        self.CPUStart       = 0
        self.CPUEnd         = 0
        self.GPUStart       = 0
        self.GPUEnd         = 0
        self.queueAhead     = 0

        # Most important:)
        self.frameTime      = 0
        self.time           = 0

# Part of the data that is associated with each interval
class Interval():
    def __init__(self):
        self.intervalNum    = 0
        self.warpStart      = 0
        self.warpEnd        = 0
        self.warpColor      = 0

        self.aswOn          = 0 
        self.warpMiss       = 0 
        self.appMiss        = 0 
        self.startTime      = 0 
        self.stopTime       = 0 

        # Save a pointer the app frame targetiog this interval
        self.appFrame = None

           
def float_or_na(value):
    try:
        float(value)
        return float(value)
    except ValueError:
        return(float('NaN'))

def int_or_na(value):
    try:
        int(value)
        return int(value)
    except ValueError:
        return(int('NaN'))


