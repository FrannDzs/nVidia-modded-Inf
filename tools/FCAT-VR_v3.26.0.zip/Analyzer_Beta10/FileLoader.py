import logging
import os
import re
import time

from PyQt5.QtCore import (QAbstractTableModel, QObject, QModelIndex,
                          Qt, QThread, QVariant, pyqtSignal, pyqtSlot)

from PyQt5.QtWidgets import QApplication
from DataFile import DataFile, FileState
from enum import Enum


class threadState(Enum):
    Created = 0
    Started = 1
    Finished = 2


class FileLoader(QObject):

    # A handler for threaded messages
    def loaderMsessageHandler(str, type=0):
        if type == 0:
            logging.info(str)
        if type == 1:
            logging.warn(str)
        if type == 2:
            logging.error(str)

    notifyProgress = pyqtSignal(int)
    
    def __init__(self, model=None, *args, **kwargs):
        super(QObject,self).__init__(*args, **kwargs) 
        self.model = model
        self.newDatafiles = 0

    # This is called whn a thread completes it work
    def updateStatus(self):
        self.completeCount = self.completeCount + 1
        complete = 100 * self.completeCount / self.newDatafiles 

        if complete == 100:
            complete = 0

        self.notifyProgress.emit(int(complete))
    
    def parseFilename(self, fname, root):

        # Last element is alway the file.
        (path, file) = os.path.split(fname)

        # Subtract the root of the remainder
        myRegex = re.escape(root) + r'\\(.*)'
        m = re.search(myRegex, path)

        # Did we strip off a root
        d1 = ''
        d2 = ''
        rest = ''

        if m:
            leftOver = m.group(1)
            chunks = leftOver.split('\\')

            if len(chunks) > 0:
                d1 = chunks[0]
            if len(chunks) > 1:
                d2 = chunks[1]
            if len(chunks) > 2:
                s = '+'
                rest = s.join(chunks[2:])
        else:
            # Split up what is left into 2 chuncks
            myRegex = r'(.*)\\(.*)'
            m = re.search(myRegex, path)
            if m:
                rest = m.group(2)
                left = m.group(1)

                m = re.search(myRegex, left)
                if m:
                    d2 = m.group(2)
                    left = m.group(1)

                    m = re.search(myRegex, left)
                    if m:
                        d1 = m.group(2)
                        left = m.group(1)
        
        return(d1, d2, rest, file)
    
    # Add a file or directory to the input list
    @pyqtSlot(QModelIndex, str) 
    def dropped(self, index, path):
        r = os.path.normpath(path)
        self.rootPath = r
        all = []

        #logging.info('dropped a file : %s' % path)

        # Create a new top-level no
        if (os.path.isfile(r)):
            all.append(r)

        for root, dirs, files in os.walk(r):
            for file in files:
                if (file.endswith((".CSV", ".csv", ".xls", ".xlsx"))):
                    newFile = os.path.join(root, file)
                    f = os.path.normpath(newFile)

                    # Create a new top-level node
                    all.append(f)

        # Find the part or the path for all new files taht is common (assume that is the root)
        if len(all) == 0:
            return

        # Look for first directory called "data" and use it as the root.
        myRegex = r'(.*\\data)'
        m = re.search(myRegex, self.rootPath, re.IGNORECASE)
        if m:
            myRoot = m.group(1)
        else:
            # otherwise pick the first Unique directory
            myRoot = os.path.commonpath(all)

        # Get an stsimate of the filter fields
        self.threads = []
        self.loaders = []
        self.completeCount = 0

        # Call update 2 times for each new file
        self.newDatafiles = len(all)
        doThreads = 1

        for f in all:
            (d1, d2, rest, fileName) = self.parseFilename(f,  myRoot)
            
            # Load a new datafile
            df = DataFile(self, inData = (f, d1, d2, rest, fileName))

            # Add the datafile record to the model
            self.model.addFile(df)

            # setup a new thread
            loader = Loader(df)
            self.loaders.append(loader)
            
            if doThreads:
                thread = QThread()
                self.threads.append(thread)
                self.loaders[-1].moveToThread(self.threads[-1])
                self.threads[-1].started.connect(self.loaders[-1].process)                          # Connect the threads started signal to the work function in the worker object          
                self.loaders[-1].allDone.connect(self.threads[-1].quit)                             # Connect up the worker terminating signal to a cleanup function 

            else:
                # Some progress
                self.updateStatus()
                self.heartBeat()

                self.loaders[-1].process()

            # Signal the loader to start
            self.loaders[-1].message.connect(FileLoader.loaderMsessageHandler)                  # Connect up the message handler for thread messages
            self.loaders[-1].heartBeat.connect(self.threadHeartBeat)

        # Start all the threads
        if doThreads:
            for t in self.threads:
                t.start()

                # Some progress
                self.updateStatus()
                self.heartBeat()

            done = False
            l = 0
            while not done:
                self.heartBeat()
                n = 0
                l = l +1
                done = True
                for t in self.threads:
                    r = t.isRunning()
                    if r:
                        done = False

                    f = t.isFinished()
                    #logging.info(" %d %d Thread stats %r %r" %(l, n, r, f))
                
                    n = n+1 
        

    @pyqtSlot()
    def heartBeat(self):
        self.model.layoutChanged.emit()
        QApplication.processEvents()

    @pyqtSlot()
    def threadHeartBeat(self):
        logging.info("===From Thread")
        QApplication.processEvents()


    @pyqtSlot()
    def done(self):
        logging.info('Work done...kill thread' )
        
        # Allow the UI to update
        #self.thread.quit()
        #self.thread.wait()

        self.updateStatus()

        # Allow the UI to update
        QApplication.processEvents()

    @pyqtSlot() 
    def up(self):
        #logging.info('Thread started')
        return

    @pyqtSlot() 
    def threadDone(self):
        #logging.info('Thread done')
        return

# A threaded class for loading up data
class Loader (QObject):

    heartBeat = pyqtSignal()
    allDone = pyqtSignal()
    message = pyqtSignal(str, int)

    def __init__(self, df, *args, **kwargs):
        super(Loader,self).__init__(*args, **kwargs) 
        self.df = df
        
        # Forward the heartbeat signal back to the main thread
        df.heartBeat.connect(self.HB)
        
    @pyqtSlot() 
    def HB(self):
        self.message.emit("  -> From DF", 0)
        self.heartBeat.emit()


    @pyqtSlot() 
    def process(self):
        
        #self.message.emit('  -> Thread Run called', 0)
        time.sleep (0.01)

        # Read the inputfile        
        self.df.loadFile()
        
        # Calc stats&
        self.df.calcStats()

        # Signal complete
        #self.message.emit("  -> All done", 0)

        self.allDone.emit()
  
    def __del__(self):
        self.exiting = True
