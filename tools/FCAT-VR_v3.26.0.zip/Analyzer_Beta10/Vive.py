import logging
import math

from PyQt5.QtCore import QObject, Qt
from Structs import *
from PyQt5.QtCore import pyqtSignal, pyqtSlot

class Vive (QObject):
    
    loaderMsg = pyqtSignal(str,int)


    def __init__(self, *args, **kwargs):
        super(Vive, self).__init__(*args, **kwargs)
    
    def parseFile(self, reader, appFrames, intervals):
        
        startTime = float('NaN')

        # Process all the rows in the reader
        for row in reader:

            # Grab the first valid Game start for the base offset
            if math.isnan(startTime):
                startTime = float_or_na(row[r'Frame start (ms)'])
                
            if  math.isnan(startTime):
                continue
            
            # Get frame and interval data
            (frame, intv) = self.parseLine (row, startTime)

            if math.isnan(frame.frameTime):
                self.loaderMsg.emit('Skipping invalid frame read @ %d' % frame.frameNumber, 2) 
                continue

            # Detect if this is same app frame  - If it is then don't add a new frame
            if len (appFrames):
                if not (frame.frameNumber !=  appFrames[-1].frameNumber -1):
                    self.loaderMsg.emit('Frame Skipped at %d' % frame.frameNumber, 2) 

                if (frame.frameNumber ==  appFrames[-1].frameNumber):
                    self.loaderMsg.emit('Frame Repeated at %d' % frame.frameNumber, 2) 

                # Each line is a frame
                appFrames.append(frame)
                    
            else:
                appFrames.append(frame)

            # Add an interval for each warp miss
            # 
            for wmI in range (0, intv.warpMiss):
                
                # Add an interval for each time the frame was presented
                i = Interval()
                i.time = intv.time
                i.warpMiss = 1
                i.appMiss = 1
                intervals.append(i)

                # Increment time for next frame
                intv.time = intv.time + 11.11/1000 

            # Add an interval for each app miss
            for missI in range (0, intv.presented):
                i = Interval()
                i.time = intv.time
                i.appMiss = 0
                i.warpMiss = 0
                
                # Every freame except the last is an app miss
                if missI < intv.presented -1:
                    i.appMiss = 1
                
                intervals.append(i)
            
                # Increment time for next frame
                intv.time = intv.time + 11.11/1000 



    # Parse one line line of the input
    def parseLine(self, row, startTime):

        f = appFrame()
        intv = Interval()

        # timings for an appFrame
        f.frameNumber   = int_or_na(row[r'Frame Index'])
        f.queueAhead    = 0
        f.CPUStart      = 0
        f.CPUEnd        = 0
            
        # Sad that we dont have a trimestamp for GPU render start
        f.GPUStart      = 0
        f.GPUEnd        = 0

        # Calculated frametime
        f.frameTime     = float_or_na(row[r'Total GPU render time (ms)'])
        f.time          = (float_or_na(row[r'Frame start (ms)']) - startTime) /1000

        # Timings related to an interval
        intv.warpStart  = 0
        intv.warpEnd    = 0

        intv.presented  = int_or_na(row[r'Number Times Presented'])
        

        intv.warpMiss   = int_or_na(row[r'Number Dropped Frames']) 
            
        # App Miss no longer used
        # int_or_na(row[r'App Miss Count'])
        #intv.reprojectType    = int_or_na(row[r'Reprojection Flags'])
        intv.aswOn      = 0
        intv.time       = f.time
 
        return(f, intv)
        