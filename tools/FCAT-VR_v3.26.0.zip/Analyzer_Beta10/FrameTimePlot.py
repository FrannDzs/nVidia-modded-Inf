import logging
import re

from functools import partial
from PlotItems import CrossHair
from LegendItem import LegendItem

import pyqtgraph as pg
from PyQt5.QtCore import pyqtSignal, pyqtSlot
from PyQt5.QtCore import Qt, QPoint
import PyQt5.QtGui as qtg 

# Reporensent a Frametime curve item
class FrameTimeCurveItem (pg.PlotCurveItem):

    amdPlots=0
    nvPlots=0
    otherPlots=0

    # Some default curve colors
    nvColors = [
            'lime',
            'darkGreen',
            'olive',
            'teal',
            '#85cf40',
            ]

    amdColors = [
            'red',
            'darkRed',
            'brown',
            'orange',
            'orange',
            ]

    otherColors = [
            '#5500ff',
            '#ff02c8',
            '#00ffff',
            '#fcff34',
            '#a2bbd0',
            ]
        
    def __init__(self, *args, **kwds):
        super(FrameTimeCurveItem, self).__init__( *args, **kwds)

    # Setting up connection between a dataset and a curve
    def setDataset(self, ds):
        self.ds = ds
        
        # Start the pen wih pen saved in the dataset - or a new default pen if none exists
        pen = self.getPen(ds)
        
        # Set current draw pen to the default pen
        self.setPen(pen)

        # Set up refrence to data for the curve
        data = ds.frameTimes()
        self.setData(x=data[:,0], y=data[:,1])
        self.setClickable(True, 5)

    # Color has been updated by user
    def updatePen(self, pen):
        self.ds.pen = pen
        self.setPen(pen)
        
        # Force a redraw
        self.update()

    def updateD(self):
        
        # recalc stats
        self.ds.calcStats()
        
        data = self.ds.frameTimes()
        self.setData(x=data[:,0], y=data[:,1])
   

    def getPen(self,ds):

        if ds.pen:
           return(ds.pen)

        # Split up what is left into 2 chuncks
        nvRegex = 'GTX|NV|Titan'
        nvName = re.search(nvRegex, self.ds.name())
        amdRegex = 'RD|RX|AMD|Fury'
        amdName = re.search(amdRegex,  self.ds.name())

        if FrameTimeCurveItem.nvPlots >=5:
            FrameTimeCurveItem.nvPlots = 0

        if FrameTimeCurveItem.amdPlots >=5:
            FrameTimeCurveItem.amdPlots = 0

        if FrameTimeCurveItem.otherPlots >=5:
            FrameTimeCurveItem.otherPlots = 0

        if nvName:
            color = qtg.QColor(self.nvColors[FrameTimeCurveItem.nvPlots])
            FrameTimeCurveItem.nvPlots = FrameTimeCurveItem.nvPlots +1
        elif amdName:
            color = qtg.QColor(self.amdColors[FrameTimeCurveItem.amdPlots])
            FrameTimeCurveItem.amdPlots = FrameTimeCurveItem.amdPlots +1
        else:
            color = qtg.QColor(self.otherColors[FrameTimeCurveItem.otherPlots])
            FrameTimeCurveItem.otherPlots = FrameTimeCurveItem.otherPlots + 1

        ds.pen = pg.mkPen(color)

        return(ds.pen)


# The entire collection of frametime curves        
class FrametimePlot(pg.PlotItem):

    plotClicked = pyqtSignal(FrameTimeCurveItem)
    addIntervalPlot = pyqtSignal()
    clearIntervalPlot = pyqtSignal()
    
    def __init__(self, *args, **kwargs):

        super(FrametimePlot, self).__init__(*args, **kwargs)

        # Setup the Frametime plot
        self.pen = pg.mkPen('r')
        self.menu = None

        self.showGrid(y=True, alpha=0.4)
        self.setLimits(yMin=0)
        self.setLimits(xMin=0)
        self.setLimits(xMax=1000)
        
        # Set up the marker
        self.cursor = 0.0
        self.lastCursor = 0.04
        self.marker = pg.InfiniteLine(angle=90, movable=False)
        self.marker.setPen(pg.mkPen('b'))
        self.marker.setPos(self.lastCursor)

        self.addItem(self.marker, ignoreBounds=True)
        self.curveFT = []

        # Adding in a legend        
        self.legend = LegendItem()
        self.legend.setParentItem(self)
        self.legend.anchor((1,0), (1,0), (-10, 40))
    
    def removeCurves(self):
        for cur in self.curveFT:
            self.removeItem(cur)
        self.legend.reset()

    def addDataset(self, ds, color):

        # Create a new Curve
        ftime = FrameTimeCurveItem()
        ftime.setDataset(ds)
        ftime.sigClicked.connect(partial(self.curveClicked, ftime))

        # Add the curve to the plot
        self.addItem(ftime)

        # Add to the legend
        self.legend.addItem(ftime, ftime.ds.name(),  qtg.QColor(color))
        self.curveFT.append(ftime)

    # When a plot is clicked....and select the plot
    def curveClicked(self, other):

        curve = self.sender()
        self.selectedCurve = curve
        self.selectedDataset = curve.ds

        # Reset all curves back to current colors
        for cs in self.curveFT:
            p = cs.ds.pen
            cs.setPen(p)
            cs.ds.deselect()

        curve.setPen(pg.mkPen('y'))
        curve.ds.select()

        logging.info(curve.ds.fullpath + ' Selected')
        self.plotClicked.emit(curve)

    def setColor(self):
        try: 
            if self.selectedCurve:
                colorDialog = qtg.QColorDialog()
                color = colorDialog.getColor(self.selectedDataset.pen.color(), options = qtg.QColorDialog.ShowAlphaChannel)
                if color.isValid():
                    self.selectedCurve.updatePen(pg.mkPen(color))
        except:
            return

    def setWidth(self):
        try: 
            if self.selectedCurve:
                num,ok = qtg.QInputDialog.getInt(None, "Line Width", "Enter line width in pixels")

            if ok:
                self.selectedCurve.updatePen(pg.mkPen( color=self.selectedDataset.pen.color(), width=num))
        except:
            return


    # On right-click, raise the context menu
    def mouseClickEvent(self, ev):
        if ev.button() == Qt.RightButton:
            #self.marker.setPos(0)
            if self.raiseContextMenu(ev):
                ev.accept()

        # Set a "marker"
        if ev.button() == Qt.LeftButton:
          
            # Reset all curves back to current colors
            for cs in self.curveFT:
                cs.ds.deselect()  
            
            # Save the last click position                
            self.lastCursor = self.cursor
            self.marker.setPos(self.lastCursor)

    def raiseContextMenu(self, ev):
        # Make sure a curve is selected
        menu = self.getContextMenus()
        try:
            if self.selectedCurve:
                pos = ev.screenPos()
                menu.popup(QPoint(pos.x(), pos.y()))
                return True
        except:
            return True

    def getContextMenus(self, event=None):
        if self.menu is None:
            self.menu = qtg.QMenu()
            
            setC = qtg.QAction("Set Color", self.menu)
            setC.triggered.connect(self.setColor)
            self.menu.addAction(setC)

            setC = qtg.QAction("Set Width", self.menu)
            setC.triggered.connect(self.setWidth)
            self.menu.addAction(setC)

            setS = qtg.QAction("Set Region", self.menu)
            setS.triggered.connect(self.setRegion)
            self.menu.addAction(setS)

            setO = qtg.QAction("Move Dataset", self.menu)
            setO.triggered.connect(self.moveStart)
            self.menu.addAction(setO)

            setZ = qtg.QAction("Move Dataset to 0.0", self.menu)
            setZ.triggered.connect(self.moveToZero)
            self.menu.addAction(setZ)

            setR = qtg.QAction("ClearTimes", self.menu)
            setR.triggered.connect(self.resetTime)
            self.menu.addAction(setR)

            self.menu.addSeparator()

            setSA = qtg.QAction("Set Region (all)", self.menu)
            setSA.triggered.connect(self.setRegionAll)
            self.menu.addAction(setSA)

            moveATZ = qtg.QAction("Move to 0.0 (all)", self.menu)
            moveATZ.triggered.connect(self.moveAlltoZero)
            self.menu.addAction(moveATZ)
    
            cta = qtg.QAction("ClearTimes (all)", self.menu)
            cta.triggered.connect(self.clearTimesAll)
            self.menu.addAction(cta)

            self.menu.addSeparator()

            atp = qtg.QAction("Add to Interval Plot", self.menu)
            atp.triggered.connect(self.addIP)
            self.menu.addAction(atp)

            ctp = qtg.QAction("Clear Interval Plots", self.menu)
            ctp.triggered.connect(self.clearIP)
            self.menu.addAction(ctp)

        return self.menu

    def setRegion(self):
        
        # Clip the dataset beteen the current cursors
        if not self.lastCursor:
            return

        if self.cursor < self.lastCursor:
            start = self.cursor
            stop = self.lastCursor
        else:
            start = self.lastCursor
            stop = self.cursor

        self.selectedCurve.ds.startTime = start
        self.selectedCurve.ds.stopTime = stop

        self.selectedCurve.updateD()
        self.plotClicked.emit(None)

        
    def setRegionAll(self):
        # Clip the dataset beteen the current cursors
        if not self.lastCursor:
            return

        if self.cursor < self.lastCursor:
            start = self.cursor
            stop = self.lastCursor
        else:
            start = self.lastCursor
            stop = self.cursor

        # Reset all curves back to current colors
        for cs in self.curveFT:
            cs.ds.startTime = start
            cs.ds.stopTime = stop
            cs.updateD()

        self.plotClicked.emit(None)

    def moveAlltoZero(self):
        # Reset all curves back to current colors
        for cs in self.curveFT:
            start = cs.ds.startTime
            offset = cs.ds.offset

            # Adjust offset and start/stop
            cs.ds.startTime = 0.0
            cs.ds.offset = offset - start
            cs.ds.stopTime = cs.ds.stopTime - start
            cs.updateD()

        self.plotClicked.emit(None)

    def clearTimesAll(self):
        for cs in self.curveFT:
            cs.ds.startTime = 0
            cs.ds.stopTime = 100000
            cs.ds.offset = 0
            cs.updateD()

        self.plotClicked.emit(None)

    def moveToZero(self):
        # Reset all curves back to current colors
        cs = self.selectedCurve
        start = cs.ds.startTime
        offset = cs.ds.offset

        # Adjust offset and start/stop
        cs.ds.startTime = 0.0
        cs.ds.offset = offset - start
        cs.ds.stopTime = cs.ds.stopTime - start
        cs.updateD()
        self.plotClicked.emit(None)

    def moveStart(self):
        # get the xposition / time of the cursor
        delta = self.cursor - self.lastCursor
        self.lastCursor =  self.lastCursor + delta
        self.marker.setPos(self.lastCursor)

        self.selectedCurve.ds.offset = self.selectedCurve.ds.offset + delta
        self.selectedCurve.ds.startTime = self.selectedCurve.ds.startTime + delta
        self.selectedCurve.ds.stopTime = self.selectedCurve.ds.stopTime + delta
        self.selectedCurve.updateD()
        self.plotClicked.emit(None)

    def setStop(self):
        # get the xposition / time of the cursor
        self.selectedCurve.ds.stopTime = self.lastCursor
        self.selectedCurve.updateD()
        self.plotClicked.emit(None)

    def resetTime(self):
        # Temp defaults
        self.selectedCurve.ds.startTime = 0
        self.selectedCurve.ds.stopTime = 100000
        self.selectedCurve.ds.offset = 0
        self.selectedCurve.updateD()
        self.plotClicked.emit(None)

    def addIP(self):
        self.addIntervalPlot.emit()

    def clearIP(self):
        self.clearIntervalPlot.emit()

    
