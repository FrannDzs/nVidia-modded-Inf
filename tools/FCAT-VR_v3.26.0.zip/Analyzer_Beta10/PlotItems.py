import logging

import pyqtgraph as pg
from PyQt5.QtCore import pyqtSignal, pyqtSlot
from PyQt5.QtCore import QObject
import PyQt5.QtGui as qtg 

class CrossHair(QObject):

    def __init__(self, *args, ftp, **kwargs):
        super(CrossHair, self).__init__(*args, **kwargs) 
        self.setObjectName("Crosshair")

        self.frameTimePlot = ftp
        self.currentCurve = None
        self.plots = []
        self.vLines = []

        # Add a crosshair
        self.vLine = pg.InfiniteLine(angle=90, movable=False)
        #self.vLine.setPen ( qtg.QPen(qtg.QColor(255, 255, 255, 255)))
        self.text = pg.TextItem("test", anchor=(1.0, 2.0))
        self.text.setParentItem(self.vLine)

        self.frameTimePlot.addItem(self.vLine, ignoreBounds=True)
        
    def addPlot(self, plot):    
        self.plots.append(plot)
        line = pg.InfiniteLine(angle=90, movable=False)
        #line.setPen(qtg.QPen(qtg.QColor(255, 255, 255, 255)))
        self.vLines.append(line)
        self.plots[-1].addItem(self.vLines[-1], ignoreBounds=True)

    def setCurrentCurve(self, curve):
        self.currentCurve = curve

    def mouseMoved(self, pos):
        if self.frameTimePlot.sceneBoundingRect().contains(pos):
            mousePoint = self.frameTimePlot.vb.mapSceneToView(pos)
            x = mousePoint.x()
            
            if x<0:
                return
                
            self.vLine.setPos(x)

            # Save the cursor position
            self.frameTimePlot.cursor = x
            
            if self.currentCurve:
                (dx,dy) =  self.currentCurve.getData()
                
                # find the index 
                for index in range (0, len(dx)):
                    if dx[index] >= x:
                        break

                y = dy[index]


                self.text.setText('[%0.3f (s), %0.1f (ms)]' % (x, y))
            else:
                self.text.setText('[%0.3f (s), %0.1f (ms)]' % (x, 0.0))
    
            # Move all the add Vlines
            for vLine in self.vLines:
                vLine.setPos(mousePoint.x())

