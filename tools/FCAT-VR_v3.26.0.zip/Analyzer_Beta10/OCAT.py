import logging
import math

from PyQt5.QtCore import QObject, Qt
from Structs import *
from PyQt5.QtCore import pyqtSignal, pyqtSlot

class OCAT (QObject):

    loaderMsg = pyqtSignal(str,int)

    def __init__(self, *args, **kwargs):
        super(OCAT, self).__init__(*args, **kwargs)
    
    def parseFile(self, reader, appFrames, intervals):
        
        startTime = float('NaN')
        warpColorChanging = 0    
        rowNum = 0
        # Process all the rows in the reader
        for row in reader:
            rowNum = rowNum +1

            # Grab the first valid Game start for the base offset
            if math.isnan(startTime):
                startTime = float_or_na(row[r'TimeInSeconds'])
                
            if  math.isnan(startTime):
                continue

            # Get frame and interval data
            (frame, intv) = self.parseLine (row, startTime)

            appFrames.append(frame)
            intervals.append(intv)


    # Parse one line line of the input
    def parseLine(self, row, startTime):

        f = appFrame()
        intv = Interval()

        # timings for an appFrame
        f.frameNumber   = 0
        f.time          = (float_or_na(row[r'TimeInSeconds']) - startTime)
        
        f.frameTime     = float_or_na(row[r'MsBetweenDisplayChange'])
        if f.frameTime == 0:
            f.frameTime     = float_or_na(row[r'MsBetweenPresents'])
        
        intv.time       = f.time 

        return(f, intv)
        
