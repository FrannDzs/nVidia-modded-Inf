import logging

#from LegendItem import LegendItem
from PlotItems import CrossHair
from FrameTimePlot import FrameTimeCurveItem, FrametimePlot
from IntervalPlot import IntervalPlot
from Structs import *

import pyqtgraph as pg
import pyqtgraph.exporters
from   PyQt5.QtCore import Qt, pyqtSignal, pyqtSlot

import PyQt5.QtGui as qtg 
import PyQt5.QtCore
from pyqtgraph import GraphicsLayoutWidget


# Layouts in general don;t contain children.
class PlotLayoutWidget(GraphicsLayoutWidget):
    
    updateView = pyqtSignal()

    def __init__(self, *args, **kwargs):
        super(PlotLayoutWidget, self).__init__(*args, **kwargs) 

        # Add the frametime plot
        self.frameTimePlot = FrametimePlot(self.ci)

        self.ci.addItem(self.frameTimePlot, row=0,col=0)
        self.frameTimePlot.plotClicked.connect(self.updateView)
        self.frameTimePlot.plotClicked.connect(self.updateIntervalPlots)

        self.frameTimePlot.addIntervalPlot.connect(self.addIntervalPlot)
        self.frameTimePlot.clearIntervalPlot.connect(self.clearIntervalPlot)

        self.ci.layout.setRowStretchFactor(0, 2)
        #self.ci.layout.setRowStretchFactor(1, 1)
        self.intervalPlot = []
        self.iplotnum = 1

        # Update crosshair
        self.crossHair = CrossHair(self, ftp=self.frameTimePlot)
        self.frameTimePlot.scene().sigMouseMoved.connect(self.crossHair.mouseMoved)
        self.frameTimePlot.plotClicked.connect(self.crossHair.setCurrentCurve)
        self.frameTimePlot.plotClicked.connect(self.resizeEvent)
    
    def addModel(self, model):
        self.model = model

    def addSelModel(self, selModel):
        self.selModel = selModel

    def addIntervalPlot(self):
        logging.info ('Plotting Interval')
        
        # Add the interval plot
        self.intervalPlot.append(IntervalPlot(self.ci, ftp=self.frameTimePlot, curve=self.frameTimePlot.selectedCurve))
        self.ci.addItem(self.intervalPlot[-1],  row=self.iplotnum, col=0)
        self.ci.layout.setRowStretchFactor(1, 1)
        self.iplotnum = self.iplotnum +1
        
        # Uplot the new interval data
        self.intervalPlot[-1].plotIntervals()
        self.crossHair.addPlot(self.intervalPlot[-1])

        return

    def updateIntervalPlots(self):
        logging.info ('Resetting Intervals')
        
        for ip in self.intervalPlot:
            ip.refreshData()

    def clearIntervalPlot(self):
        #self.frameTimePlot.removeCurves()
        
        for p in self.intervalPlot:
            #p.removeCurves()
            self.ci.removeItem(p)

        self.intervalPlot = []
        self.iplotnum = 1

    def replot(self):
        self.frameTimePlot.removeCurves()

        # selected Indexes 
        FrameTimeCurveItem.nvPlots = 0
        FrameTimeCurveItem.amdPlots = 0
        FrameTimeCurveItem.otherPlots = 0

        # Loop through the selected datasets
        num = 0
        for index in self.selModel.selectedRows():
            
            dataset = self.model.data(index, Qt.UserRole)
            
            # Check for valid dataset
            if dataset.state == FileState.VALID:
                logging.info ('Plotting %s' % dataset.fullpath)
            
                self.frameTimePlot.addDataset(dataset, self.fColor)
                num = num +1
                if num >= 8:
                    logging.warn ('Plotting Stopped after 8 datasets')
                    break

    def exportView(self): 
        exporter = pg.exporters.ImageExporter(self.sceneObj)
        name = qtg.QFileDialog.getSaveFileName(None, 'Save File', filter='*.png')

        # Look to see if the extension got added
        if name:
            filename = name[0]
            if not filename.endswith('.png'):
                filename = filename +".png"
            
            logging.info("Saving %s" % filename)
            exporter.export(filename)

   