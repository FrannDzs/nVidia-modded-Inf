import re
import logging
import numpy as np

from PyQt5.QtCore import (QAbstractItemModel, QModelIndex, QObject, QRegExp,
                          QSortFilterProxyModel, Qt, QTime, QTimer, QVariant,
                          pyqtSignal, pyqtSlot)
from PyQt5.QtGui import QBrush, QFont

from DataFile import FileState, FileType
from Model import Model

class FileProxy(QSortFilterProxyModel):
    
    def __init__(self, *args, **kwargs):
        super(FileProxy,self).__init__(*args, **kwargs) 
        self.cindex = [2, 3, 4, 5]
        self.regexin = [None]*4
        self.regexout = [None]*4
        self.regexoutRaw = ['']*4

    def lessThan(self, sourceLeftIndex, sourceRightIndex):
        lvalue = self.sourceModel().data(sourceLeftIndex)
        rvalue = self.sourceModel().data(sourceRightIndex)
        if type(lvalue) == FileType or type(lvalue) == FileState:
            test = lvalue.name < rvalue.name
        else:
            if type(lvalue) ==  np.float64 or type(rvalue) == np.float64:
                if not lvalue:
                    lvalue = -0.1
                if not rvalue:
                    rvalue = -0.1
            
            if type(lvalue) ==  int or type(rvalue) == int:
                if not lvalue:
                    lvalue = -1
                if not rvalue:
                    rvalue = -1

            test = lvalue < rvalue
       
        return test

    # Return an index to the original model
    def modelIndex(self, proxyRow, proxyCol):
        pindex = self.index(proxyRow, proxyCol)
        mindex = self.mapToSource(pindex)
        return mindex

    def filterChanged(self, string):
        # Syntax of the filter text
        sObjectName = self.sender().objectName()
        
        # Parse the object name
        myRegex = '(.*)(.)$'
        m = re.search(myRegex, sObjectName)
        type = m.group(1)
        idx = int(m.group(2)) - 1

        if type == 'in':
            syntax = QRegExp.RegExp
            casesensitivity = Qt.CaseSensitive
            self.regexin[idx] = QRegExp(string, casesensitivity, syntax)
        elif type == 'ex':
            syntax = QRegExp.RegExp
            casesensitivity = Qt.CaseSensitive
            self.regexoutRaw[idx] = string
            self.regexout[idx] = QRegExp(string, casesensitivity, syntax)
        elif type == 'combo':
            self.cindex[idx] = string
                        
        self.invalidateFilter()

    # Returns true if a row pointed to by parent and row should be included.
    def filterAcceptsRow(self, modelRow, modelParentIndex):
        acceptrow = True

        # Loom at all the regexes
        for idx in range(0,4):
            if self.regexin[idx]:

                mi = self.sourceModel().index(modelRow, self.cindex[idx])
                d = repr(self.sourceModel().data(mi))
                if not self.regexin[idx].indexIn(d) >= 0:
                    acceptrow = False

        for idx in range(0,4):
            if self.regexout[idx]:
                if len (self.regexoutRaw[idx]) > 0:
                    mi = self.sourceModel().index(modelRow, self.cindex[idx])
                    d = repr(self.sourceModel().data(mi))
                    if self.regexout[idx].indexIn(d) >= 0:
                        acceptrow = False

        return acceptrow

    def addFile(self, df):
        self.sourceModel().addFile(df)

    def clear(self):
        self.sourceModel().clear()

