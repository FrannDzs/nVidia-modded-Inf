import logging
import math

from PyQt5.QtCore import QObject, Qt
from Structs import *
from PyQt5.QtCore import pyqtSignal, pyqtSlot

class HWCap (QObject):

    colorSequence = [
        [ "white"           , '0xffFFFF'],
        [ "green"           , '0x00ff00'],
        [ "blue"            , '0x0000ff'],
        [ "red"             , '0xff0000'],
    
        [ "teal"            , '0xff0000'],
        [ "purple"          , '0xff0000'],
        [ "lime"            , '0xff0000'],
        [ "cyan"            , '0x00ffff'],
        
        [ "olive"           , '0x00ffff'],
        [ "lightgrey"       , '0x00ffff'],
        [ "lightpurple"     , '0xff00ff'],
        [ "lightolive"      , '0xff00ff'],
        
        [ "grey"            , '0xff00ff'],
        [ "pink"            , '0xff00ff'],
        [ "yellow"          , '0xffff00'],
        [ "orange"          , '0xffff00']]
    


    loaderMsg = pyqtSignal(str,int)

    def __init__(self, *args, **kwargs):
        super(HWCap, self).__init__(*args, **kwargs)
    
    def parseFile(self, reader, appFrames, intervals):

        startTime = float('NaN')
        rowNum = 0

        # Process all the rows in the reader
        for row in reader:
            rowNum = rowNum +1

            # Grab the first valid Game start for the base offset
            if math.isnan(startTime):
                startTime = float_or_na(row[r'frame start (s)'])
                
            if  math.isnan(startTime):
                continue

            # Get frame and interval data
            (frame, intv) = self.parseLine (row, startTime)

            appFrames.append(frame)
            intervals.append(intv)



    # Parse one line line of the input
    def parseLine(self, row, startTime):

        f = appFrame()
        intv = Interval()

        # timings for an appFrame
        f.frameNumber   = int_or_na(row[r'frame'])
        f.queueAhead    = 0
        f.CPUStart      = 0
        f.CPUEnd        = 0
            
        # Sad that we dont have a trimestamp for GPU render start
        f.GPUStart      = 0
        f.GPUEnd        = 0
        f.appColor      = row[r'color']
        (f.appColorNum, f.appColorName) = self.getColorName (f.appColor, 2000)

        # Calculated frametime
        f.frameTime     = 0
        f.time          = float_or_na(row[r'time (ms)'])
        intv.time       = f.time 
        return(f, intv)


    # Calculate the steps between two colors
    def colorSteps(self, colorArray, cOld, cNew):
        
        # Find c1 in the array
        cOldIndex = -1
        cNewIndex = -1

        i = 0
        for (n,c) in colorArray:
            if self.colorMatch(c, cOld):
                cOldIndex = i
            if self.colorMatch(c, cNew):
                cNewIndex = i

            i = i +1

        # Find c1 in the array
        if cOldIndex == -1 or cNewIndex == -1:
            return -1

        steps = cNewIndex - cOldIndex
        if steps < 0:
            steps = steps + len(colorArray)

        return (steps)


    def colorMatch(self, c1, c2, maxDistance=1600):
        # convert each string to triplets
        (r1, g1, b1) = self.hex_to_rgb(c1)
        (r2, g2, b2) = self.hex_to_rgb(c2)

        err = (r1-r2)**2 + (g1-g2)**2 + (b1-b2)**2
        return (err < maxDistance)
    
    def hex_to_rgb(self, value):
        r = int(value[2:4], 16)
        g = int(value[4:6], 16)
        b = int(value[6:8], 16)

        return (r, g, b)

    def getColorName(self, color, maxDistance=40):
        return(0, self.colorSequence[0])


class VR_HWCap (QObject):

    colorSequenceVR = [
        [ "black"   , '0x000000'],
        [ "white"   , '0xffffff'],
        [ "red"     , '0xff0000'],
        [ "green"   , '0x00ff00'],
        [ "blue"    , '0x0000ff'],
        [ "yellow"  , '0xffff00'],
        [ "magenta" , '0xff00ff'],
        [ "cyan"    , '0x00ffff']]
    
    
    loaderMsg = pyqtSignal(str,int)

    def __init__(self, *args, **kwargs):
        super(VR_HWCap, self).__init__(*args, **kwargs)
    
    def parseFile(self, reader, appFrames, intervals):
        
        startTime = float('NaN')
        warpColorChanging = 0    
        rowNum = 0
        # Process all the rows in the reader
        for row in reader:
            rowNum = rowNum +1

            # Grab the first valid Game start for the base offset
            if math.isnan(startTime):
                startTime = float_or_na(row[r'time (ms)'])
                
            if  math.isnan(startTime):
                continue

            # Get frame and interval data
            (frame, intv) = self.parseLine (row, startTime)
            
            # See if we have gotten an interval yet                
            step = 0    
            if len (intervals):
                lastIntv     = intervals[-1]                  
                step = (intv.time - lastIntv.time)*1000

                # Looking for a warp miss
                # if the color is changing make sure that the sequence is only advancing by 1 color                        
                increment = self.colorSteps(self.colorSequenceVR, lastIntv.warpColor, intv.warpColor)

                if increment == 0:
                    if warpColorChanging:
                        intv.warpMiss = 1                    
                        print ('Warp Miss Old %s New %s' % (lastIntv.warpColor, intv.warpColor))
                
                elif increment == 1:

                    # Look for a change in color on warp in the first 5 intervals.....if not...then assume overlay is missing (AMD)
                    if rowNum < 5:
                        warpColorChanging = 1
                
                # Increment by more than 1....Error
                else:
                    print ('Warp skip %s New %s - D: %d' % (lastIntv.warpColor, intv.warpColor, increment))


            # This is a dropped frame if app colors match
            if len (appFrames):
                lastFrame   = appFrames[-1]

                # Matching colors is a dropped frame
                increment = self.colorSteps(self.colorSequenceVR, frame.appColor, lastFrame.appColor)
                
                #logging.info('Check Frame Old %s New %s - D: %3.1f' % (lastFrame.appColor, frame.appColor, distance))
                if increment == 0:
                    intv.appMiss = 1
                    logging.info('Dropped')
                        
                    # Update last frametime
                    lastFrame.frameTime  =  lastFrame.frameTime  + step
                else:
                    frame.frameTime  =  step
                    intv.appMiss = 0
            else:
                # Someday fix this hack for first interval
                frame.frameTime  =  11.1

            # Save a new game frame if no app miss
            if not (intv.appMiss):
                appFrames.append(frame)

            # Save interval info
            intervals.append(intv)


    # Parse one line line of the input
    def parseLine(self, row, startTime):

        f = appFrame()
        intv = Interval()

        # timings for an appFrame
        f.frameNumber   = int_or_na(row[r'frame'])
        f.queueAhead    = 0
        f.CPUStart      = 0
        f.CPUEnd        = 0
            
        # Sad that we dont have a trimestamp for GPU render start
        f.GPUStart      = 0
        f.GPUEnd        = 0
        f.appColor      = row[r'app color']
        (f.appColorNum, f.appColorName) = self.getColorName (f.appColor, 2000)

        # Calculated frametime
        f.frameTime     = 0
        f.time          = (float_or_na(row[r'time (ms)']) - startTime)/1000

        # Timings related to an interval
        intv.warpColor  = row[r'warp color']
        (intv.warpColorNum, intv.warpColorName) = self.getColorName (intv.warpColor, 2000)
        intv.warpStart  = 0
        intv.warpEnd    = 0
        intv.warpEnd    = 0

        intv.warpMiss   = 0
        intv.appMiss    = 0
        intv.aswOn      = 0
        intv.time       = f.time 
 
        return(f, intv)
        

    # Calculate the steps between two colors
    def colorSteps(self, colorArray, cOld, cNew):
        
        # Find c1 in the array
        cOldIndex = -1
        cNewIndex = -1

        i = 0
        for (n,c) in colorArray:
            if self.colorMatch(c, cOld):
                cOldIndex = i
            if self.colorMatch(c, cNew):
                cNewIndex = i

            i = i +1

        # Find c1 in the array
        if cOldIndex == -1 or cNewIndex == -1:
            return -1

        steps = cNewIndex - cOldIndex
        if steps < 0:
            steps = steps + len(colorArray)

        return (steps)


    def colorMatch(self, c1, c2, maxDistance=1600):
        # convert each string to triplets
        (r1, g1, b1) = self.hex_to_rgb(c1)
        (r2, g2, b2) = self.hex_to_rgb(c2)

        err = (r1-r2)**2 + (g1-g2)**2 + (b1-b2)**2
        return (err < maxDistance)
    
    def hex_to_rgb(self, value):
        r = int(value[2:4], 16)
        g = int(value[4:6], 16)
        b = int(value[6:8], 16)

        return (r, g, b)

    def getColorName(self, color, maxDistance=40):
        return(0, self.colorSequenceVR[0])