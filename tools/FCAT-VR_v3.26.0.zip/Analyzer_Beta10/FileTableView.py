import os
import logging
import numpy as np

from PyQt5.QtWidgets import QTableView, QWidget, QItemDelegate, QStyle, QHeaderView, QAbstractItemView
from PyQt5.QtGui import QPen, QBrush, QDropEvent, QDragEnterEvent, QDragMoveEvent
from PyQt5.QtCore import Qt, pyqtSignal, QModelIndex, pyqtSlot, QItemSelection, QItemSelectionModel

from DataFile import FileState, FileType


class FileTableView (QTableView):

    # define a new signal for a dropped file
    drop = pyqtSignal(QModelIndex, str)

    def __init__(self, *args, **kwargs):
        super(FileTableView, self).__init__(*args, **kwargs) 

        # Set the delegate
        self.setItemDelegateForColumn(0,StateDelegate(self))
        self.setItemDelegateForColumn(1,TypeDelegate(self))
        self.setItemDelegate(DefaultDelegate(self))
        self.setItemDelegateForColumn(4,DefaultDelegate(self))
        
        self.setAcceptDrops(True)
        self.setSortingEnabled(True)
        self.setWordWrap(False)
        self.verticalHeader().setResizeMode(QHeaderView.ResizeToContents)

        # Signal for doubleclick        
        self.doubleClicked.connect (self.rowSelected)

    # Support Drag and Drop
    @pyqtSlot(QDragEnterEvent)
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    @pyqtSlot(QDragMoveEvent)
    def dragMoveEvent(self, event):
        event.accept()
   
    @pyqtSlot(QDropEvent) 
    def dropEvent(self, event):
        if event.mimeData().hasUrls:
            event.setDropAction(Qt.CopyAction)
            event.accept()
            for url in event.mimeData().urls():
                path = url.toLocalFile()
                if os.path.isdir(path):
                    target = self.indexAt(event.pos())
                    self.drop.emit(target, path)

                elif os.path.isfile(path):
                    target = self.indexAt(event.pos())
                    self.drop.emit(target, path)


    @pyqtSlot(QModelIndex) 
    def rowSelected(self, modelIndex):

        # The passed index is from whatever model the view is using (in my case proxy)
        pr = modelIndex.row()
        pc = modelIndex.column()

        #logging.info ('Table index %d, %d --- selecting : %d' % (pr, pc, selected))
        #self.fileNameClicked.emit(modelIndex)
        return

                             
class DefaultDelegate (QItemDelegate):
    def __init__(self, *args, **kwargs):
        super(DefaultDelegate, self).__init__(*args, **kwargs) 

    def paint(self, painter, option, index):

        col = index.column()

        painter.save()

        if option.state & QStyle.State_Selected:
            painter.setBrush(QBrush(Qt.gray))
            painter.drawRect(option.rect)

        # When a 
        selected = index.data(Qt.CheckStateRole)            
        if selected:
            painter.setPen(QPen(Qt.yellow))
        else:
            painter.setPen(QPen(Qt.black))

        # set text color
        value = index.data(Qt.DisplayRole)

        # get the selection status 
        item = index.data(Qt.UserRole)            
        if item.selected:
            painter.setPen(QPen(Qt.red))
        else:
            painter.setPen(QPen(Qt.black))
            
        # Convert floats 
        t = type(value)

        if t == np.float64:
            if int(value) == value:
                text = '%d' % value
            else:
                text = '%.2f' % value
        elif t == int:
            text = '%d' % value
        else:
            text = value
            
        painter.drawText(option.rect, Qt.AlignRight | Qt.AlignVCenter, text)
        painter.restore()        

            
class StateDelegate (QItemDelegate):
    def __init__(self, *args, **kwargs):
        super(StateDelegate, self).__init__(*args, **kwargs) 

    def paint(self, painter, option, index):
        painter.save()
        
        r = index.row()
        c = index.row()


        if option.state & QStyle.State_Selected:
            painter.setBrush(QBrush(Qt.gray))
            painter.drawRect(option.rect)

        value = index.data(Qt.DisplayRole)

        if value == FileState.INVALID:
            painter.setBrush(Qt.red)
        if value == FileState.VALID:
            painter.setBrush(Qt.green)
        if value == FileState.LOADING:
            painter.setBrush(Qt.gray)

        # for circle make the ellipse radii match
        radx = 5
        rady = 5
        painter.drawEllipse(option.rect.center(), radx, rady)
        painter.restore()        

            
class TypeDelegate (QItemDelegate):
    def __init__(self, *args, **kwargs):
        super(TypeDelegate, self).__init__(*args, **kwargs) 

    def paint(self, painter, option, index):

        r = index.row()
        c = index.column()

        painter.save()
        if option.state & QStyle.State_Selected:
            painter.setBrush(QBrush(Qt.gray))
            painter.drawRect(option.rect)

        # get the selection status 
        item = index.data(Qt.UserRole)            
        if item.selected:
            painter.setPen(QPen(Qt.red))
        else:
            painter.setPen(QPen(Qt.black))
        
        text = '-'
        if item.type == FileType.VR_SW_VIVE:
            text = 'VIVE'
        if item.type == FileType.VR_SW_OCC:
            text = 'RIFT'
        if item.type == FileType.VR_SW_MS_MR:
            text = 'MS_AR'
        if item.type == FileType.VR_HW:
            text = 'HW Cap'
        if item.type == FileType.FRAPS:
            text = 'FRAPS'
        if item.type == FileType.OCAT:
            text = 'OCAT'

        # Use the decoded string
        painter.drawText(option.rect, Qt.AlignCenter | Qt.AlignVCenter, text)
        painter.restore()        

