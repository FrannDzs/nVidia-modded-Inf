import logging

class Logger(logging.Handler):
    def __init__(self, textWidget):
        super().__init__()
        self.widget = textWidget
        self.widget.setReadOnly(True)    

        self.setFormatter(logging.Formatter('%(threadName)s:  %(thread)d  %(levelname)s - %(message)s'))
        
        # Set up the calls to use this handler
        logging.getLogger().addHandler(self)
        logging.getLogger().setLevel(logging.DEBUG)

    def emit(self, record):
        msg = self.format(record)
        self.widget.append(msg)    

        #print(msg)

