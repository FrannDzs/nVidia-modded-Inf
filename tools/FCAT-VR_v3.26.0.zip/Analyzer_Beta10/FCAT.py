import sys
import csv
from Log import Logger
from PyQt5.QtWidgets import QApplication, QMainWindow, QAbstractItemView
from FileProxy import FileProxy
from Model import Model
from FileLoader import FileLoader
from PyQt5.QtCore import Qt, pyqtSignal, QModelIndex, pyqtSlot, QItemSelection, QItemSelectionModel
from PyQt5.QtWidgets import QFileDialog
import PyQt5.QtGui as qtg 
import configparser

from UI import Ui_MainWindow
from SettingsUI import Ui_Settings


class MySettings(QMainWindow, Ui_Settings):

    def __init__(self, parent=None):
        super(MySettings, self).__init__(parent)

        # Load UI widgets
        self.setupUi(self)


class MyApp(QMainWindow, Ui_MainWindow):


    def __init__(self, parent=None):
        super(MyApp, self).__init__(parent)

        # Load UI widgets
        self.setupUi(self)

        self.log = Logger(self.logTextBox)

        # Load up a config parser object
        self.config = configparser.SafeConfigParser()
        self.configFile = "default.ini"
        
        # Set some global defauls for settigns
        self.config.read_dict ( {
                'Global': {
                    'plotTitle'             : "Frametime Plot",
                    'titleFont'             : "20",
                    'backgroundColor'       : "white",
                    'foregroundColor'       : "black",
                    'legendFont'            : "15",
                    'axisFont'              : "15",
                    'xAxisName'             : "Time (s)",
                    "xAxisMin"              : "0",
                    "xAxisMax"              : "1000",
                    'yAxisName'             : "Frametime (ms)",
                    "yAxisMin"              : "0",
                    "yAxisMax"              : "33",
                    }
                }
                            )
        # Read the current Config
        self.config.read(self.configFile)
        self.saveConfig()
        
        # Apply the current config settings
        self.setupOptions()

        # Setup Option Callbacks
        self.plotTitle.editingFinished.connect      (self.setupOptions)
        self.titleFont.editingFinished.connect      (self.setupOptions)
        self.foregroundColor.editingFinished.connect(self.setupOptions)
        self.backgroundColor.editingFinished.connect(self.setupOptions)
        self.axisFont.editingFinished.connect       (self.setupOptions)
        self.legendFont.editingFinished.connect     (self.setupOptions)
        self.xAxisName.editingFinished.connect      (self.setupOptions)
        self.xAxisMin.editingFinished.connect       (self.setupOptions)
        self.xAxisMax.editingFinished.connect       (self.setupOptions)
        self.yAxisName.editingFinished.connect      (self.setupOptions)
        self.yAxisMin.editingFinished.connect       (self.setupOptions)
        self.yAxisMax.editingFinished.connect       (self.setupOptions)

        # Load the models and views
        model = Model(self)
        proxymodel = FileProxy(self)
        proxymodel.setSourceModel(model)

        # Pick the model
        self.mod = proxymodel
        self.inputTree.setModel(self.mod)
        
        # Needs to happen after the model is set
        self.selModel = self.inputTree.selectionModel()
        self.inputTree.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.inputTree.setSelectionMode(QAbstractItemView.MultiSelection)
      
        self.graphicsLayout.addModel(self.mod)
        self.graphicsLayout.addSelModel(self.selModel)
        self.graphicsLayout.updateView.connect(self.update)

        # Create a file loader that adds to the model
        fileLoader = FileLoader(self.mod, parent=self)
        self.inputTree.drop.connect(fileLoader.dropped)
        fileLoader.notifyProgress.connect(self.pbUpdate)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setRange(0, 100)
        
        # Initialize the comboboxes
        self.combo1.insertItems(0, Model.drop_header_labels)
        self.combo1.setCurrentIndex(2)
        self.combo2.insertItems(0, Model.drop_header_labels)
        self.combo2.setCurrentIndex(3)
        self.combo3.insertItems(0, Model.drop_header_labels)
        self.combo3.setCurrentIndex(4)
        self.combo4.insertItems(0, Model.drop_header_labels)
        self.combo4.setCurrentIndex(5)
        self.combo1.currentIndexChanged.connect(self.mod.filterChanged)
        self.in1.textChanged.connect(self.mod.filterChanged)
        self.ex1.textChanged.connect(self.mod.filterChanged)
        self.combo2.currentIndexChanged.connect(self.mod.filterChanged)
        self.in2.textChanged.connect(self.mod.filterChanged)
        self.ex2.textChanged.connect(self.mod.filterChanged)
        self.combo3.currentIndexChanged.connect(self.mod.filterChanged)
        self.in3.textChanged.connect(self.mod.filterChanged)
        self.ex3.textChanged.connect(self.mod.filterChanged)
        self.combo4.currentIndexChanged.connect(self.mod.filterChanged)
        self.in4.textChanged.connect(self.mod.filterChanged)
        self.ex4.textChanged.connect(self.mod.filterChanged)

        # Connect up Button callbacks
        self.replot.clicked.connect(self.graphicsLayout.replot)
        self.savePlot.clicked.connect(self.graphicsLayout.exportView)
        self.saveSummary.clicked.connect(self.saveStats)
        self.clearLog.clicked.connect(self.logTextBox.clear)
        self.clearselection.clicked.connect(self.clearSelection)
        self.clearInput.clicked.connect(self.mod.clear)

        self.actionSave_Global_Settings.triggered.connect(self.saveConfig)


    def saveConfig(self):       
        # write changes back to the config file
        with open(self.configFile, "w") as CF:
            self.config.write(CF)
            

    # Frametime PLot options
    def setupOptions(self):

        # Check if this was the reult of a UI edit
        senderObject = self.sender()
        if senderObject:
            text = senderObject.text()
            objectName = str(senderObject.objectName())
           
            # Set the config element based on the caller
            self.config.set("Global", objectName, text)
        
        # When called directly....set the UI to match the current config
        else:
            section = "Global"
            for option in self.config.options(section):        
                value = self.config.get(section, option)
                # print ("Default %s %s" % (option, value))
                

        # Apply all the global options 
        section = "Global"
        
        option = "backgroundColor"
        bg = self.config.get(section, option)
        self.backgroundColor.setText(bg)

        c = qtg.QColor(bg)
        if c:
            self.graphicsLayout.setBackground(c)
        
        # Set one function for all global options        
        option = "foregroundColor"
        fColor = self.config.get(section, option)
        self.graphicsLayout.fColor = fColor
        self.foregroundColor.setText(fColor)

        option = "plotTitle"
        title = self.config.get(section, option)
        self.plotTitle.setText(title)

        option = "titleFont"
        tFont = self.config.get(section, option)
        self.titleFont.setText(tFont)
        tHTML ='<p style="font-size:%spx\"><font color = \"%s\">%s' % (tFont, fColor, title)
        self.graphicsLayout.frameTimePlot.setTitle(tHTML)

        option = "axisFont"
        aFont = self.config.get(section, option)
        self.axisFont.setText(aFont)

        option = "xAxisName"
        xName = self.config.get(section, option)
        self.xAxisName.setText(xName)
        tHTML ='<p style="font-size:%spx\"><font color = \"%s\">%s' % (aFont, fColor, xName)
        self.graphicsLayout.frameTimePlot.setLabel(axis='bottom', text = tHTML)

        option = "yAxisName"
        yName = self.config.get(section, option)
        self.yAxisName.setText(yName)
        tHTML ='<p style="font-size:%spx\"><font color = \"%s\">%s' % (aFont, fColor, yName)
        self.graphicsLayout.frameTimePlot.setLabel(axis='left', text = tHTML)

        option = "legendFont"
        lFont = self.config.get(section, option)
        self.legendFont.setText(lFont)
        self.graphicsLayout.frameTimePlot.legend.setFont(lFont+"pt", color=fColor)

        option = "xAxisMin"
        xMin = self.config.get(section, option)
        self.xAxisMin.setText(xMin)

        option = "xAxisMax"
        xMax = self.config.get(section, option)
        self.xAxisMax.setText(xMax)

        option = "yAxisMin"
        yMin = self.config.get(section, option)
        self.yAxisMin.setText(yMin)

        option = "yAxisMax"
        yMax = self.config.get(section, option)
        self.yAxisMax.setText(yMax)

        # Setup plot
        self.graphicsLayout.frameTimePlot.setRange(yRange =[float(yMin), float(yMax)])
        self.graphicsLayout.frameTimePlot.setRange(xRange =[float(xMin), float(xMax)])

    def clearSelection(self):
        self.selModel.clearSelection()
              
    # Update the progressbar
    def pbUpdate(self, i):
        self.progressBar.setValue(i)

    def saveStats(self):
        (name, ext) = QFileDialog.getSaveFileName(None, 'Save Results File', None, "CSV files (*.csv);;All Files (*)")

        if name:
            with open(name, 'w') as csvfile:

                spamwriter = csv.writer(
                    csvfile, delimiter=',', quotechar='"', lineterminator='\n',
                    quoting=csv.QUOTE_MINIMAL)

                spamwriter.writerow(self.mod.sourceModel().header_labels)

                for index in self.selModel.selectedRows():
                    dataset = self.mod.data(index, Qt.UserRole)
                    spamwriter.writerow(dataset.readDataAll(len(self.mod.sourceModel().header_labels)))
    
    def update(self):
        self.mod.layoutChanged.emit()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyApp()
    #Swindow = MySettings()
    
    window.show()
    #Swindow.show()
    sys.exit(app.exec_())
