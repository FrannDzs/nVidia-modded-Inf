Direct3D 12 feature checker (October 2016) by DmitryKo
https://forum.beyond3d.com/posts/1840641

D3D12CheckFeatureSupport.exe is a simple Windows 10 console app which calls IDXGIAdapter2::GetDesc2 and ID3D12Device::CheckFeatureSupport interfaces to check the supported Direct3D 12 options for every graphics adapter in the system, then outputs the text report to the console screen.

It shows parameters provided by DXGI_ADAPTER_DESC2, D3D12_FEATURE_FEATURE_LEVELS, D3D12_FEATURE_D3D12_OPTIONS, D3D12_FEATURE_ARCHITECTURE, D3D12_FEATURE_GPU_VIRTUAL_ADDRESS_SUPPORT, D3D12_FEATURE_D3D12_OPTIONS1,� D3D12_SHADER_MODEL, D3D_ROOT_SIGNATURE_VERSION,�D3D12_FEATURE_D3D12_OPTIONS2, D3D12_FEATURE_ARCHITECTURE1 and D3D12_FEATURE_SHADER_CACHE.

Requires Visual C++ Redistributable for Visual Studio 2017 (x86): https://go.microsoft.com/fwlink/?LinkId=746571


Usage:

Run checkfeatures.cmd to write a list of supported feature options and texture formats to D3D12FeatureOptions.txt and to the screen.


Command line arguments:

/level=12_0 - create Direct3D 12 device using minimum feature level 12_0 (also accepts dot as the delimiter: 12.0);
/adapter=1 - only check features for adapter enumerated as 1;
/devid=008C - only check features for the specified device (008C - Microsoft Basic Render Driver);
/venid=8086 - only check graphics cards by specified vendor (1002 - AMD, 10DE - NVIDIA, 1414 - Microsoft, 8086 - Intel);

/formats - adds a short list of supported texture formats with options (FEATURE_SUPPORT1 and FEATURE_SUPPORT2) provided as hex values;
/verbose - list each supported format option as both verbose text and hex value.


Common errors:

 Failed to create Direct3D 12 device
 Error 887A0004: The specified device interface or feature level is not supported on this system.

DXGI_ERROR_UNSUPPORTED - either a) Direct3D 12 DDI is not supported by the driver; or
b) Minimum feature level was set higher than the maximum feature level supported by the driver (for example, requesting level 12_0 for level 11_1 graphics cards).

 Failed to create Direct3D 12 device
 Error 80070057: The parameter is incorrect.

E_INVALIDARG - minimum feature level is out of the range (from 11_0 to 12_1) currently allowed by the Windows SDK.


Changelog

April 3, 2015: Initial release.

May 1, 2015: Allow querying Microsoft Basic Render Driver - Direct3D 12 support requires installing the latest Windows 10 SDK to update the WARP software renderer. Recompiled with the latest Windows SDK beta and VS2015 preview.

July 4, 2015: Update to accept minimum feature level, adapter number, vendor ID and device ID from the command line, and list supported texture formats and format options.

July 30, 2015: Show maximum feature level in Direct3D 11.3 when it doesn't match Direct3D 12 maximum feature level. Recompiled with Windows SDK 10.0.10240 and Visual Studio 2015 release. 

August 6, 2016: Update to report new features in Windows 10 Anniversary Update version 1607. Recompiled with Windows SDK 10.0.14393 and Visual Studio 2015 Update 3. 

October 16, 2016: Update to work around batch file limitation of stripping equal sign characters from command-line arguments.

March 24, 2017: Update to report new features in Windows 10 Creators Update version 1703, along with Windows version and build number. Recompiled with Windows SDK 10.0.15063 and Visual Studio 2017.1 Preview.