// D3D12CheckFeatureSupport.cpp : Defines the entry point for the console application.

//#pragma comment(lib, "d3d12.lib d3d11.lib d3d9.lib dxgi.lib dxguid.lib")
#define _CRT_SECURE_NO_WARNINGS	
#pragma warning (disable : 4996)

#include <d3d12.h>
#include <d3d9.h>
#include <d3d11_4.h>
#include <dxgi1_6.h>
#include <VersionHelpers.h>
#include <Windows.h>
#include <comdef.h>
#include <stdio.h>
#include <tchar.h>
#include <time.h>
#include <strsafe.h>
#include <intrin.h> 


//#include <wbemidl.h>
//#pragma comment(lib, "wbemuuid.lib")
//#define __STDC_WANT_LIB_EXT1__

IDXGIFactory4* pFactory = nullptr;
IDXGIAdapter3* pAdapter = nullptr;
ID3D12Device*  pDevice = nullptr;

DXGI_ADAPTER_DESC2 AdapterDesc;
D3D12_FEATURE_DATA_ARCHITECTURE   FeatureDataArchitecture;
D3D12_FEATURE_DATA_ARCHITECTURE1   FeatureDataArchitecture1;
D3D12_FEATURE_DATA_GPU_VIRTUAL_ADDRESS_SUPPORT FeatureDataGPUVirtualAddressSupport;
D3D12_FEATURE_DATA_SHADER_MODEL FeatureDataShaderModel;
D3D12_FEATURE_DATA_ROOT_SIGNATURE FeatureDataRootSignature;

D3D12_FEATURE_DATA_D3D12_OPTIONS FeatureDataOptions;
D3D12_FEATURE_DATA_D3D12_OPTIONS1 FeatureDataOptions1;
D3D12_FEATURE_DATA_D3D12_OPTIONS2 FeatureDataOptions2;
D3D12_FEATURE_DATA_FEATURE_LEVELS FeatureDataFeatureLevels;
D3D12_FEATURE_DATA_SHADER_CACHE FeatureDataShaderCache;
D3D12_FEATURE_DATA_FORMAT_SUPPORT  FeatureDataFormatSupport;

D3D_FEATURE_LEVEL FeatureLevel = D3D_FEATURE_LEVEL_9_1;

const D3D_FEATURE_LEVEL FeatureLevels[] = {
	D3D_FEATURE_LEVEL_9_1,  D3D_FEATURE_LEVEL_9_2, D3D_FEATURE_LEVEL_9_3,
	(D3D_FEATURE_LEVEL)0x9400 /* D3D_FEATURE_LEVEL_9_4 */,
	D3D_FEATURE_LEVEL_10_0, D3D_FEATURE_LEVEL_10_1,
	D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_11_1,
	D3D_FEATURE_LEVEL_12_0, D3D_FEATURE_LEVEL_12_1,
	(D3D_FEATURE_LEVEL)0xc200 /* D3D_FEATURE_LEVEL_12_2 */,
	(D3D_FEATURE_LEVEL)0xd000 /* D3D_FEATURE_LEVEL_13_0 */,
	(D3D_FEATURE_LEVEL)0xd100 /* D3D_FEATURE_LEVEL_13_1 */,
	(D3D_FEATURE_LEVEL)0xd200 /* D3D_FEATURE_LEVEL_13_2 */,
	(D3D_FEATURE_LEVEL)0xe000 /* D3D_FEATURE_LEVEL_14_0 */,
	(D3D_FEATURE_LEVEL)0xe100 /* D3D_FEATURE_LEVEL_14_1 */,
	(D3D_FEATURE_LEVEL)0xe200 /* D3D_FEATURE_LEVEL_14_2 */,
	(D3D_FEATURE_LEVEL)0xf000 /* D3D_FEATURE_LEVEL_15_0 */,
	(D3D_FEATURE_LEVEL)0xf100 /* D3D_FEATURE_LEVEL_15_1 */,
	(D3D_FEATURE_LEVEL)0xf200 /* D3D_FEATURE_LEVEL_15_2 */

}; //Included yet undefined levels just for gags; Direct3D 12 runtime doesn't seem to care

const D3D_FEATURE_LEVEL FeatureLevels11[] = {
	//Reverse order for D3D11CreateDevice
	D3D_FEATURE_LEVEL_12_1, 	D3D_FEATURE_LEVEL_12_0,
	D3D_FEATURE_LEVEL_11_1,		D3D_FEATURE_LEVEL_11_0,
	D3D_FEATURE_LEVEL_10_1,		D3D_FEATURE_LEVEL_10_0,
	D3D_FEATURE_LEVEL_9_3, 	D3D_FEATURE_LEVEL_9_2, 	D3D_FEATURE_LEVEL_9_1
};

//DXGI_FORMAT
struct DxgiFormat {
	DXGI_FORMAT id;
	const char* name;
	const char* modifier;
};

const DxgiFormat Formats[] =
{
	{ DXGI_FORMAT_UNKNOWN, "UNKNOWN" , "" }, //0
	{ DXGI_FORMAT_R32G32B32A32_TYPELESS, "R32G32B32A32" , "_TYPELESS" }, //1
	{ DXGI_FORMAT_R32G32B32A32_FLOAT, "R32G32B32A32" , "_FLOAT" }, //2
	{ DXGI_FORMAT_R32G32B32A32_UINT, "R32G32B32A32" , "_UINT" }, //3
	{ DXGI_FORMAT_R32G32B32A32_SINT, "R32G32B32A32" , "_SINT" }, //4
	{ DXGI_FORMAT_R32G32B32_TYPELESS, "R32G32B32" , "_TYPELESS" }, //5
	{ DXGI_FORMAT_R32G32B32_FLOAT, "R32G32B32" , "_FLOAT" }, //6
	{ DXGI_FORMAT_R32G32B32_UINT, "R32G32B32" , "_UINT" }, //7
	{ DXGI_FORMAT_R32G32B32_SINT, "R32G32B32" , "_SINT" }, //8
	{ DXGI_FORMAT_R16G16B16A16_TYPELESS, "R16G16B16A16" , "_TYPELESS" }, //9
	{ DXGI_FORMAT_R16G16B16A16_FLOAT, "R16G16B16A16" , "_FLOAT" }, //10
	{ DXGI_FORMAT_R16G16B16A16_UNORM, "R16G16B16A16" , "_UNORM" }, //11
	{ DXGI_FORMAT_R16G16B16A16_UINT, "R16G16B16A16" , "_UINT" }, //12
	{ DXGI_FORMAT_R16G16B16A16_SNORM, "R16G16B16A16" , "_SNORM" }, //13
	{ DXGI_FORMAT_R16G16B16A16_SINT, "R16G16B16A16" , "_SINT" }, //14
	{ DXGI_FORMAT_R32G32_TYPELESS, "R32G32" , "_TYPELESS" }, //15
	{ DXGI_FORMAT_R32G32_FLOAT, "R32G32" , "_FLOAT" }, //16
	{ DXGI_FORMAT_R32G32_UINT, "R32G32" , "_UINT" }, //17
	{ DXGI_FORMAT_R32G32_SINT, "R32G32" , "_SINT" }, //18
	{ DXGI_FORMAT_R32G8X24_TYPELESS, "R32G8X24" , "_TYPELESS" }, //19
	{ DXGI_FORMAT_D32_FLOAT_S8X24_UINT, "D32_FLOAT_S8X24_UINT" , "" }, //20
	{ DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS, "R32_FLOAT_X8X24_TYPELESS" , "" }, //21
	{ DXGI_FORMAT_X32_TYPELESS_G8X24_UINT, "X32_TYPELESS_G8X24_UINT" , "" }, //22
	{ DXGI_FORMAT_R10G10B10A2_TYPELESS, "R10G10B10A2" , "_TYPELESS" }, //23
	{ DXGI_FORMAT_R10G10B10A2_UNORM, "R10G10B10A2" , "_UNORM" }, //24
	{ DXGI_FORMAT_R10G10B10A2_UINT, "R10G10B10A2" , "_UINT" }, //25
	{ DXGI_FORMAT_R11G11B10_FLOAT, "R11G11B10" , "_FLOAT" }, //26
	{ DXGI_FORMAT_R8G8B8A8_TYPELESS, "R8G8B8A8" , "_TYPELESS" }, //27
	{ DXGI_FORMAT_R8G8B8A8_UNORM, "R8G8B8A8" , "_UNORM" }, //28
	{ DXGI_FORMAT_R8G8B8A8_UNORM_SRGB, "R8G8B8A8" , "_UNORM_SRGB" }, //29
	{ DXGI_FORMAT_R8G8B8A8_UINT, "R8G8B8A8" , "_UINT" }, //30
	{ DXGI_FORMAT_R8G8B8A8_SNORM, "R8G8B8A8" , "_SNORM" }, //31
	{ DXGI_FORMAT_R8G8B8A8_SINT, "R8G8B8A8" , "_SINT" }, //32
	{ DXGI_FORMAT_R16G16_TYPELESS, "R16G16" , "_TYPELESS" }, //33
	{ DXGI_FORMAT_R16G16_FLOAT, "R16G16" , "_FLOAT" }, //34
	{ DXGI_FORMAT_R16G16_UNORM, "R16G16" , "_UNORM" }, //35
	{ DXGI_FORMAT_R16G16_UINT, "R16G16" , "_UINT" }, //36
	{ DXGI_FORMAT_R16G16_SNORM, "R16G16" , "_SNORM" }, //37
	{ DXGI_FORMAT_R16G16_SINT, "R16G16" , "_SINT" }, //38
	{ DXGI_FORMAT_R32_TYPELESS, "R32" , "_TYPELESS" }, //39
	{ DXGI_FORMAT_D32_FLOAT, "D32" , "_FLOAT" }, //40
	{ DXGI_FORMAT_R32_FLOAT, "R32" , "_FLOAT" }, //41
	{ DXGI_FORMAT_R32_UINT, "R32" , "_UINT" }, //42
	{ DXGI_FORMAT_R32_SINT, "R32" , "_SINT" }, //43
	{ DXGI_FORMAT_R24G8_TYPELESS, "R24G8" , "_TYPELESS" }, //44
	{ DXGI_FORMAT_D24_UNORM_S8_UINT, "D24_UNORM_S8_UINT" , "" }, //45
	{ DXGI_FORMAT_R24_UNORM_X8_TYPELESS, "R24_UNORM_X8_TYPELESS" , "" }, //46
	{ DXGI_FORMAT_X24_TYPELESS_G8_UINT, "X24_TYPELESS_G8_UINT" , "" }, //47
	{ DXGI_FORMAT_R8G8_TYPELESS, "R8G8" , "_TYPELESS" }, //48
	{ DXGI_FORMAT_R8G8_UNORM, "R8G8" , "_UNORM" }, //49
	{ DXGI_FORMAT_R8G8_UINT, "R8G8" , "_UINT" }, //50
	{ DXGI_FORMAT_R8G8_SNORM, "R8G8" , "_SNORM" }, //51
	{ DXGI_FORMAT_R8G8_SINT, "R8G8" , "_SINT" }, //52
	{ DXGI_FORMAT_R16_TYPELESS, "R16" , "_TYPELESS" }, //53
	{ DXGI_FORMAT_R16_FLOAT, "R16" , "_FLOAT" }, //54
	{ DXGI_FORMAT_D16_UNORM, "D16" , "_UNORM" }, //55
	{ DXGI_FORMAT_R16_UNORM, "R16" , "_UNORM" }, //56
	{ DXGI_FORMAT_R16_UINT, "R16" , "_UINT" }, //57
	{ DXGI_FORMAT_R16_SNORM, "R16" , "_SNORM" }, //58
	{ DXGI_FORMAT_R16_SINT, "R16" , "_SINT" }, //59
	{ DXGI_FORMAT_R8_TYPELESS, "R8" , "_TYPELESS" }, //60
	{ DXGI_FORMAT_R8_UNORM, "R8" , "_UNORM" }, //61
	{ DXGI_FORMAT_R8_UINT, "R8" , "_UINT" }, //62
	{ DXGI_FORMAT_R8_SNORM, "R8" , "_SNORM" }, //63
	{ DXGI_FORMAT_R8_SINT, "R8" , "_SINT" }, //64
	{ DXGI_FORMAT_A8_UNORM, "A8" , "_UNORM" }, //65
	{ DXGI_FORMAT_R1_UNORM, "R1" , "_UNORM" }, //66
	{ DXGI_FORMAT_R9G9B9E5_SHAREDEXP, "R9G9B9E5_SHAREDEXP" , "" }, //67
	{ DXGI_FORMAT_R8G8_B8G8_UNORM, "R8G8_B8G8" , "_UNORM" }, //68
	{ DXGI_FORMAT_G8R8_G8B8_UNORM, "G8R8_G8B8" , "_UNORM" }, //69
	{ DXGI_FORMAT_BC1_TYPELESS, "BC1" , "_TYPELESS" }, //70
	{ DXGI_FORMAT_BC1_UNORM, "BC1" , "_UNORM" }, //71
	{ DXGI_FORMAT_BC1_UNORM_SRGB, "BC1" , "_UNORM_SRGB" }, //72
	{ DXGI_FORMAT_BC2_TYPELESS, "BC2" , "_TYPELESS" }, //73
	{ DXGI_FORMAT_BC2_UNORM, "BC2" , "_UNORM" }, //74
	{ DXGI_FORMAT_BC2_UNORM_SRGB, "BC2" , "_UNORM_SRGB" }, //75
	{ DXGI_FORMAT_BC3_TYPELESS, "BC3" , "_TYPELESS" }, //76
	{ DXGI_FORMAT_BC3_UNORM, "BC3" , "_UNORM" }, //77
	{ DXGI_FORMAT_BC3_UNORM_SRGB, "BC3" , "_UNORM_SRGB" }, //78
	{ DXGI_FORMAT_BC4_TYPELESS, "BC4" , "_TYPELESS" }, //79
	{ DXGI_FORMAT_BC4_UNORM, "BC4" , "_UNORM" }, //80
	{ DXGI_FORMAT_BC4_SNORM, "BC4" , "_SNORM" }, //81
	{ DXGI_FORMAT_BC5_TYPELESS, "BC5" , "_TYPELESS" }, //82
	{ DXGI_FORMAT_BC5_UNORM, "BC5" , "_UNORM" }, //83
	{ DXGI_FORMAT_BC5_SNORM, "BC5" , "_SNORM" }, //84
	{ DXGI_FORMAT_B5G6R5_UNORM, "B5G6R5" , "_UNORM" }, //85
	{ DXGI_FORMAT_B5G5R5A1_UNORM, "B5G5R5A1" , "_UNORM" }, //86
	{ DXGI_FORMAT_B8G8R8A8_UNORM, "B8G8R8A8" , "_UNORM" }, //87
	{ DXGI_FORMAT_B8G8R8X8_UNORM, "B8G8R8X8" , "_UNORM" }, //88
	{ DXGI_FORMAT_R10G10B10_XR_BIAS_A2_UNORM, "R10G10B10_XR_BIAS_A2" , "_UNORM" }, //89
	{ DXGI_FORMAT_B8G8R8A8_TYPELESS, "B8G8R8A8" , "_TYPELESS" }, //90
	{ DXGI_FORMAT_B8G8R8A8_UNORM_SRGB, "B8G8R8A8" , "_UNORM_SRGB" }, //91
	{ DXGI_FORMAT_B8G8R8X8_TYPELESS, "B8G8R8X8" , "_TYPELESS" }, //92
	{ DXGI_FORMAT_B8G8R8X8_UNORM_SRGB, "B8G8R8X8" , "_UNORM_SRGB" }, //93
	{ DXGI_FORMAT_BC6H_TYPELESS, "BC6H" , "_TYPELESS" }, //94
	{ DXGI_FORMAT_BC6H_UF16, "BC6H" , "_UF16" }, //95
	{ DXGI_FORMAT_BC6H_SF16, "BC6H" , "_SF16" }, //96
	{ DXGI_FORMAT_BC7_TYPELESS, "BC7" , "_TYPELESS" }, //97
	{ DXGI_FORMAT_BC7_UNORM, "BC7" , "_UNORM" }, //98
	{ DXGI_FORMAT_BC7_UNORM_SRGB, "BC7" , "_UNORM_SRGB" }, //99
	{ DXGI_FORMAT_AYUV, "AYUV" , "" }, //100
	{ DXGI_FORMAT_Y410, "Y410" , "" }, //101
	{ DXGI_FORMAT_Y416, "Y416" , "" }, //102
	{ DXGI_FORMAT_NV12, "NV12" , "" }, //103
	{ DXGI_FORMAT_P010, "P010" , "" }, //104
	{ DXGI_FORMAT_P016, "P016" , "" }, //105
	{ DXGI_FORMAT_420_OPAQUE, "420_OPAQUE" , "" }, //106
	{ DXGI_FORMAT_YUY2, "YUY2" , "" }, //107
	{ DXGI_FORMAT_Y210, "Y210" , "" }, //108
	{ DXGI_FORMAT_Y216, "Y216" , "" }, //109
	{ DXGI_FORMAT_NV11, "NV11" , "" }, //110
	{ DXGI_FORMAT_AI44, "AI44" , "" }, //111
	{ DXGI_FORMAT_IA44, "IA44" , "" }, //112
	{ DXGI_FORMAT_P8, "P8" , "" }, //113
	{ DXGI_FORMAT_A8P8, "A8P8" , "" }, //114
	{ DXGI_FORMAT_B4G4R4A4_UNORM, "B4G4R4A4" , "_UNORM" }, //115
	{ DXGI_FORMAT_P208, "P208" , "" }, //130
	{ DXGI_FORMAT_V208, "V208" , "" }, //131
	{ DXGI_FORMAT_V408, "V408" , "" }//, //132
						
};

void errorfailedto(HRESULT hr, char* customtext)
{	//E_INVALIDARG
	_com_error error(hr);
	LPCTSTR errorText = error.ErrorMessage();

	printf("Failed to %s\n", customtext);
	printf("Error %X: %ls\n\n", hr, (wchar_t*)errorText);
	return;
};


UINT32 HammingWeight(UINT32 i)
{
	// Number of bits set to "1" for a 32-bit integer
	// https://en.wikipedia.org/wiki/Hamming_weight
	int CPUInfo[4];
	
	__cpuid(CPUInfo, 1);

	if (CPUInfo[2] & 0x800000)
		return __popcnt(i);
	else
	{
		i = i - ((i >> 1) & 0x55555555);
		i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
		return (((i + (i >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
	}
};

//Windows 10 versions
//Version 1507: 10041 < build number <= 10240 (assume this as a baseline)
//Version 1511: 10525 < build number <= 10586
//Version 1607: 14251 < build number <= 14393
//Version 1703: 14901 < build number <= 1506?
//Version 1711: 1506? < build number <= 16???

typedef enum WinBuildNumber { Win1507 = 10240, Win1511 = 10586, Win1607 = 14393, Win1703 = 15063} WinBuildNumber;

//int _tmain(int argc, _TCHAR* argv[])
int main(int argc, char* argv[])

{
	puts("Direct3D 12 feature checker (March 2017) by DmitryKo");
	puts("https://forum.beyond3d.com/posts/1840641/" "\n");

	// Only run on Windows 10 and up
	if (!IsWindows10OrGreater())
	{
		puts("\nERROR:");
		printf("%s %s\n", "Windows 10", "or higher is required to run this program, exiting.\n");
		return 1;
	}

	// Get Windows version and build number
	
	OSVERSIONINFO osvi = { sizeof(osvi), 0, 0, 0, 0, {0} /*, 0, 0, 0, 0 */ };
	//ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osvi);
	//VerifyVersionInfo(&osvi,,);
		
	WinBuildNumber  buildnumber = (WinBuildNumber)osvi.dwBuildNumber;
	
	// print major version, minor version
	printf("Windows %i", osvi.dwMajorVersion);
	if (osvi.dwMinorVersion>0) printf(".%i", osvi.dwMinorVersion);
	
	//print release string and build number
	{
		HKEY hKey;
		DWORD  dwSize = 0;
		
		long lerr = RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"), NULL, KEY_READ, &hKey);
		lerr=RegQueryValueEx(hKey, TEXT("ReleaseID"), NULL, NULL, NULL, &dwSize);
		wchar_t *osversion = new wchar_t[dwSize] {};
		lerr = RegQueryValueEx(hKey, TEXT("ReleaseID"), NULL, NULL,	(LPBYTE)osversion, &dwSize);
		if (lerr == ERROR_SUCCESS) wprintf(L" version %s", osversion);
		RegCloseKey(hKey);
		delete[] osversion;
	}
	
	printf(" (build %i)\n", buildnumber);

	// Some feature options will fail the queries on older builds - need to use the build number to skip some tests
	
	//parse command-line arguments
	bool LimitToAdapter = false, LimitToDeviceId = false, LimitToVendorId = false, DeviceIdFound = false, VendorIdFound = false, SetMinimumFL = false, CheckFormats = false, VerboseFormats = false;
	UINT DeviceId, VendorId, AdapterNumber;

	D3D_FEATURE_LEVEL MinimumFeatureLevel = D3D_FEATURE_LEVEL_11_0;
	char FLTier[] = "xx_xx";


	if (argc >= 2)
	{  
	   int i = 1;
	   do {
		   char* option = nullptr;
		   // list resource formats
		   if (!strcmp(argv[i], "/formats"))
		   {
			   CheckFormats = true;
			   continue; // next i
		   }
		   // list verbose resource formats
		   if (!strcmp(argv[i], "/verbose"))
		   {
			   CheckFormats = true;
			   VerboseFormats = true;
			   continue; // next i
		   }
		   
		   // check if argument i contains parameters delimited by '='
		   option = strchr(argv[i], '=');


		   if (!strcmp(argv[i], "/level") || !strncmp(argv[i], "/level", option - argv[i]))
		   {// command-line contains minimum feature level
			   char* FLMajor = nullptr;
			   char* FLMinor = nullptr;
			   char* token = nullptr;

			   if (option != nullptr)
				   // argument contains parameters delimited by '='
				   strncpy_s(FLTier, ++option, sizeof(FLTier));
			   else
				   // argument parameter is in the next command line argument 
				   // because delimiting '=' was probably skipped by batch processor 
				   strncpy_s(FLTier, argv[++i], sizeof(FLTier));
			   // 	++i skips the next argument for processing, as it contains the data for the current argument

			   FLMajor = strtok_s(FLTier, "_.", &token);
			   FLMinor = strtok_s(nullptr, "_.", &token);

			   MinimumFeatureLevel = (D3D_FEATURE_LEVEL)(atoi(FLMajor) * 0x1000 + atoi(FLMinor) * 0x100);

			   switch (MinimumFeatureLevel)
				{
				   case D3D_FEATURE_LEVEL_11_0:
				   case D3D_FEATURE_LEVEL_11_1:
				   case D3D_FEATURE_LEVEL_12_0:
				   case D3D_FEATURE_LEVEL_12_1:
					   //feature level passed in the command line is OK
					   break;

				   default:
					   //unsupported minimum feature level 

					   printf("Warning: feature level \"%s_%s\" is not valid.\n", FLMajor, FLMinor);
					   // defaulting to 11_0	
					   //MinimumFeatureLevel = D3D_FEATURE_LEVEL_11_0;

				  }//switch case

			   SetMinimumFL = true;

			   continue; // next i
			 }// command-line contains minimum feature level

		   else if (!strcmp(argv[i], "/adapter") || !strncmp(argv[i], "/adapter", option - argv[i]))
		   {
			   // set adapter number
			   if (option != nullptr)
				   // argument contains parameters delimited by '='
				   AdapterNumber = atoi(++option);
			   else
				   // argument parameter is in the next command line argument 
				   AdapterNumber = atoi(argv[++i]);

			   LimitToAdapter = true;

			   printf("Checking adapter %u only\n", AdapterNumber);
			   continue; // next i
		   }

		   else if (!strcmp(argv[i], "/devid") || !strncmp(argv[i], "/devid", option - argv[i]))
		   {
			   // set device id

			   if (option != nullptr)
				   // argument contains parameters delimited by '='
				   DeviceId = strtoul(++option, nullptr, 16);
			   else
				   // argument parameter is in the next command line argument 
				   DeviceId = strtoul(argv[++i], nullptr, 16);

			   LimitToDeviceId = true;

			   printf("Checking adapter DEV_%.4X only\n", DeviceId);
			   continue; // next i
		   }
		   else  if (!strcmp(argv[i], "/venid") || !strncmp(argv[i], "/venid", option - argv[i]))
		   {
			   // set vendor id

			   if (option != nullptr)
				   // argument contains parameters delimited by '='
				   VendorId = strtoul(++option, nullptr, 16);
			   else
				   // argument parameter is in the next command line argument 
				   VendorId = strtoul(argv[++i], nullptr, 16);
			   
			   LimitToVendorId = true;

			   printf("Checking vendor VEN_%.4X only\n", VendorId);
			   continue; // next i
		   }
		   else
		   {
			   printf("Invalid command line argument \"%s\"\n", argv[i]);
			   continue; // next i
		   }
	   }// command-line contains parameters after '='
	 while (++i < argc); //for

		 //construct feature level string
		snprintf(FLTier, sizeof(FLTier), "%i_%i", MinimumFeatureLevel / 0x1000, (MinimumFeatureLevel & 0xFFF) / 0x100);
		if (SetMinimumFL) printf("Using minimum feature level %s\n", FLTier);
	//	if (SetMinimumFL || LimitToDeviceId || LimitToAdapter || LimitToVendorId) puts("");

	}//if (argc >= 2)

	puts("");

	 //enumerate all hardware adapters in the system and try to create a Direct3D12 device on each adapter

	UINT AdapterCount = 0;
	//Initialize DXGI
	HRESULT hr = CreateDXGIFactory1(IID_PPV_ARGS(&pFactory));
	// the macro substitutes two arguments: __uuidof(IDXGIFactory4), (void**)&pFactory

	if (FAILED(hr))
	{
		errorfailedto(hr, "create DXGIFactory");
		return 2; //fatal error
	}

	while (hr = pFactory->EnumAdapters1(AdapterCount, (IDXGIAdapter1**)&pAdapter) != DXGI_ERROR_NOT_FOUND)
	{								//have to recast IDXGIAdapter3 to IDXGIAdapter1 type for adapter enumeration to work

									// skip if not the adapter number specified in a command line argument
									// 
		if (LimitToAdapter == true && (AdapterCount != AdapterNumber))
		{
			++AdapterCount;
			pAdapter->Release();
			continue; //while EnumAdapters1
		}


		if (FAILED(hr))
		{
			printf("%s %i\n", "ADAPTER", AdapterCount);
			errorfailedto(hr, "enumerate adapter");
			++AdapterCount;
			pAdapter->Release();
			continue; //while EnumAdapters1
		}

		pAdapter->GetDesc2(&AdapterDesc); //GetDesc2 required for proper reporting of Device IDs on feature level 9_* hardware

	// skip if not the device id or vendor id specified in a command line argument
		if (LimitToDeviceId && (AdapterDesc.DeviceId != DeviceId))
		{
			++AdapterCount;
			pAdapter->Release();
			continue; //while EnumAdapters1
		}
		else
			DeviceIdFound = true;

		if (LimitToVendorId && (AdapterDesc.VendorId != VendorId))
		{
			++AdapterCount;
			pAdapter->Release();
			continue; //while EnumAdapters1
		}
		else
			VendorIdFound = true;

		//DXGI_ADAPTER_DESC2
		printf("%s %i\n", "ADAPTER", AdapterCount);
		printf("\"%ls\"\n", AdapterDesc.Description);
		printf("VEN_" "%.4X" ", DEV_" "%.4X" ", SUBSYS_" "%.8X" ", REV_" "%.2X" "\n", AdapterDesc.VendorId, AdapterDesc.DeviceId, AdapterDesc.SubSysId, AdapterDesc.Revision);
		printf("%s : %u %s\n", "Dedicated video memory", AdapterDesc.DedicatedVideoMemory, " bytes");
		printf("%s : %u %s\n", "Total video memory", AdapterDesc.DedicatedVideoMemory + AdapterDesc.DedicatedSystemMemory + AdapterDesc.SharedSystemMemory, " bytes");

		//DXGI_ADAPTER_DESC2

		if (AdapterCount == 0)
		//only the primary adapter is suppported by D3D9Ex
		{//D3DADAPTER_IDENTIFIER9

		IDirect3D9Ex* g_pD3D = nullptr;
		D3DADAPTER_IDENTIFIER9* d3dai = new D3DADAPTER_IDENTIFIER9{};
		
		//Create Direct3D9Ex interface and query the primary adapter

		if (FAILED(hr=Direct3DCreate9Ex(D3D_SDK_VERSION, &g_pD3D)))
			errorfailedto(hr, "create Direct3D 9 interface");
		else
		{ 
			if (FAILED(hr=g_pD3D->GetAdapterIdentifier(D3DADAPTER_DEFAULT, 0, d3dai)))
				errorfailedto(hr, "get adapter identifier");
			else
				printf("%s : %i.%i.%i.%i\n", "Video driver version",
					HIWORD(d3dai->DriverVersion.HighPart), LOWORD(d3dai->DriverVersion.HighPart), HIWORD(d3dai->DriverVersion.LowPart), LOWORD(d3dai->DriverVersion.LowPart) );
		}
		g_pD3D->Release();
		
		delete d3dai;
		}//D3DADAPTER_IDENTIFIER9

		//Create Direct3D 12 device on the adapter using minimum feature level
		hr = D3D12CreateDevice(pAdapter, MinimumFeatureLevel, IID_PPV_ARGS(&pDevice));
		// the macro substitutes the two arguments: __uuidof(ID3D12Device), (void**)&pDevice

		if (FAILED(hr))
		{
			errorfailedto(hr, "create Direct3D 12 device");
			pAdapter->Release();
			++AdapterCount;
			continue;//while EnumAdapters1
		}

		char* pTier = nullptr;
		
		FeatureDataFeatureLevels.pFeatureLevelsRequested = FeatureLevels;
		FeatureDataFeatureLevels.NumFeatureLevels = ARRAYSIZE(FeatureLevels);

		{//D3D12_FEATURE_DATA_FEATURE_LEVELS
			hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_FEATURE_LEVELS, &FeatureDataFeatureLevels, sizeof(D3D12_FEATURE_DATA_FEATURE_LEVELS));

			if (FAILED(hr))
			{
				errorfailedto(hr, "query Direct3D 12 maximum feature level");
			}
			else
			{

				//construct feature level string from hexadecimal values
				//just being overcautious here since you have to explicitly provide a list of FeatureLevels[] to query for 
				snprintf(FLTier, sizeof(FLTier), "%i_%i", FeatureDataFeatureLevels.MaxSupportedFeatureLevel / 0x1000,		 //  >>12,
					(FeatureDataFeatureLevels.MaxSupportedFeatureLevel & 0x0F00) / 0x100); //  >>8

				printf("%s : %s%s (%#.4x)\n", "Maximum feature level", "D3D_FEATURE_LEVEL_", FLTier, FeatureDataFeatureLevels.MaxSupportedFeatureLevel);

				//if Direct3D 11.3 maximum level mismatches Direct3D 12 maximum level, report both

				//Determine maximum supported feature level in Direct3D 11.3 without creating a D3D11 device
				hr = D3D11CreateDevice(pAdapter, D3D_DRIVER_TYPE_UNKNOWN, NULL, 0, FeatureLevels11, ARRAYSIZE(FeatureLevels11), D3D11_SDK_VERSION, NULL, &FeatureLevel, NULL);

				if (FAILED(hr))
					;//	errorfailedto(hr, "query Direct3D 11 feature levels");
				else
				if (FeatureDataFeatureLevels.MaxSupportedFeatureLevel != FeatureLevel)
				{
					snprintf(FLTier, sizeof(FLTier), "%i_%i", FeatureLevel / 0x1000,		 //  >>12,
						(FeatureLevel & 0x0F00) / 0x100); //  >>8
					printf("%s : %s%s (%#.4x)\n", " \tDirect3D 11.3", "D3D_FEATURE_LEVEL_", FLTier, FeatureLevel);
				}
			}

		}//D3D12_FEATURE_DATA_FEATURE_LEVELS


		{//D3D12_FEATURE_DATA_D3D12_OPTIONS
			hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS, &FeatureDataOptions, sizeof(D3D12_FEATURE_DATA_D3D12_OPTIONS));

			if (FAILED(hr))
					errorfailedto(hr, "query feature data");
			else
			{

				//print out option values and tiers

				printf("%s : %i\n", "DoublePrecisionFloatShaderOps", FeatureDataOptions.DoublePrecisionFloatShaderOps);

				printf("%s : %i\n", "OutputMergerLogicOp", FeatureDataOptions.OutputMergerLogicOp);

				{//D3D_SHADER_MIN_PRECISION_SUPPORT

					char* pTiers = nullptr;
					pTiers = new char[sizeof("10_BIT | 16_BIT")]();

					if (FeatureDataOptions.MinPrecisionSupport == D3D12_SHADER_MIN_PRECISION_SUPPORT_NONE)
						pTiers = "NONE";
					else
					{
						if ((FeatureDataOptions.MinPrecisionSupport &  D3D12_SHADER_MIN_PRECISION_SUPPORT_10_BIT) == D3D12_SHADER_MIN_PRECISION_SUPPORT_10_BIT)
							pTiers = strncat(pTiers, "10_BIT", sizeof("10_BIT"));
						if (HammingWeight(FeatureDataOptions.MinPrecisionSupport) > 1)
							pTiers = strncat(pTiers, " | ", sizeof(" | "));
						if ((FeatureDataOptions.MinPrecisionSupport &  D3D12_SHADER_MIN_PRECISION_SUPPORT_16_BIT) == D3D12_SHADER_MIN_PRECISION_SUPPORT_16_BIT)
							pTiers = strncat(pTiers, "16_BIT", sizeof("16_BIT"));
					};

					printf("%s : %s%s (%i)\n", "MinPrecisionSupport", "D3D12_SHADER_MIN_PRECISION_SUPPORT_", pTiers, FeatureDataOptions.MinPrecisionSupport);


				}//D3D_SHADER_MIN_PRECISION_SUPPORT

				switch (FeatureDataOptions.TiledResourcesTier)
				{
				case D3D12_TILED_RESOURCES_TIER_NOT_SUPPORTED: pTier = "NOT_SUPPORTED"; break;
				case D3D12_TILED_RESOURCES_TIER_1:        pTier = "1"; break;
				case D3D12_TILED_RESOURCES_TIER_2:        pTier = "2"; break;
				case D3D12_TILED_RESOURCES_TIER_3:        pTier = "3"; break;
				default: pTier = "???";
				}
				printf("%s : %s%s (%i)\n", "TiledResourcesTier", "D3D12_TILED_RESOURCES_TIER_", pTier, FeatureDataOptions.TiledResourcesTier);

				switch (FeatureDataOptions.ResourceBindingTier)
				{
				case D3D12_RESOURCE_BINDING_TIER_1: pTier = "1"; break;
				case D3D12_RESOURCE_BINDING_TIER_2: pTier = "2"; break;
				case D3D12_RESOURCE_BINDING_TIER_3: pTier = "3"; break;
				}
				printf("%s : %s%s (%i)\n", "ResourceBindingTier", "D3D12_RESOURCE_BINDING_TIER_", pTier, FeatureDataOptions.ResourceBindingTier);

				printf("%s : %i\n", "PSSpecifiedStencilRefSupported", FeatureDataOptions.PSSpecifiedStencilRefSupported);

				printf("%s : %i\n", "TypedUAVLoadAdditionalFormats", FeatureDataOptions.TypedUAVLoadAdditionalFormats);

				printf("%s : %i\n", "ROVsSupported", FeatureDataOptions.ROVsSupported);

				switch (FeatureDataOptions.ConservativeRasterizationTier)
				{
				case D3D12_CONSERVATIVE_RASTERIZATION_TIER_NOT_SUPPORTED: pTier = "NOT_SUPPORTED"; break;
				case D3D12_CONSERVATIVE_RASTERIZATION_TIER_1:		 pTier = "1"; break;
				case D3D12_CONSERVATIVE_RASTERIZATION_TIER_2:        pTier = "2"; break;
				case D3D12_CONSERVATIVE_RASTERIZATION_TIER_3:        pTier = "3"; break;
				}
				printf("%s : %s%s (%i)\n", "ConservativeRasterizationTier", "D3D12_CONSERVATIVE_RASTERIZATION_TIER_", pTier, FeatureDataOptions.ConservativeRasterizationTier);

				//	printf("%s : %i\n", "MaxGPUVirtualAddressBitsPerResource", FeatureDataOptions.MaxGPUVirtualAddressBitsPerResource);

				printf("%s : %i\n", "StandardSwizzle64KBSupported", FeatureDataOptions.StandardSwizzle64KBSupported);

				switch (FeatureDataOptions.CrossNodeSharingTier)
				{
				case D3D12_CROSS_NODE_SHARING_TIER_NOT_SUPPORTED:   pTier = "NOT_SUPPORTED"; break;
				case D3D12_CROSS_NODE_SHARING_TIER_1_EMULATED:		pTier = "1_EMULATED"; break;
				case D3D12_CROSS_NODE_SHARING_TIER_1:				pTier = "1"; break;
				case D3D12_CROSS_NODE_SHARING_TIER_2:				pTier = "2"; break;
				}
				printf("%s : %s%s (%i)\n", "CrossNodeSharingTier", "D3D12_CROSS_NODE_SHARING_TIER_", pTier, FeatureDataOptions.CrossNodeSharingTier);

				printf("%s : %i\n", "CrossAdapterRowMajorTextureSupported", FeatureDataOptions.CrossAdapterRowMajorTextureSupported);

				printf("%s : %i\n", "VPAndRTArrayIndexFromAnyShaderFeedingRasterizerSupportedWithoutGSEmulation",
					FeatureDataOptions.VPAndRTArrayIndexFromAnyShaderFeedingRasterizerSupportedWithoutGSEmulation);

				switch (FeatureDataOptions.ResourceHeapTier)
				{
				case D3D12_RESOURCE_HEAP_TIER_1:   pTier = "1"; break;
				case D3D12_RESOURCE_HEAP_TIER_2:   pTier = "2"; break;

				}
				printf("%s : %s%s (%i)\n", "ResourceHeapTier", "D3D12_RESOURCE_HEAP_TIER_", pTier, FeatureDataOptions.ResourceHeapTier);
			}//else
		} //D3D12_FEATURE_DATA_D3D12_OPTIONS

		  //D3D12_FEATURE_GPU_VIRTUAL_ADDRESS_SUPPORT
		hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_GPU_VIRTUAL_ADDRESS_SUPPORT, &FeatureDataGPUVirtualAddressSupport, sizeof(D3D12_FEATURE_DATA_GPU_VIRTUAL_ADDRESS_SUPPORT));

		if (FAILED(hr))
			errorfailedto(hr, "query virtual address support");
		else
		{
			printf("%s : %i\n", "MaxGPUVirtualAddressBitsPerResource", FeatureDataGPUVirtualAddressSupport.MaxGPUVirtualAddressBitsPerResource);

			printf("%s : %i\n", "MaxGPUVirtualAddressBitsPerProcess", FeatureDataGPUVirtualAddressSupport.MaxGPUVirtualAddressBitsPerProcess);

		}
		//D3D12_FEATURE_GPU_VIRTUAL_ADDRESS_SUPPORT

		{// D3D12_FEATURE_ARCHITECTURE
			UINT NodeCount = pDevice->GetNodeCount();
			for (UINT i = 0; i < NodeCount; i++)
			{
				FeatureDataArchitecture.NodeIndex = i;
				hr=pDevice->CheckFeatureSupport(D3D12_FEATURE_ARCHITECTURE, &FeatureDataArchitecture, sizeof(D3D12_FEATURE_DATA_ARCHITECTURE));
				if (FAILED(hr))
					errorfailedto(hr, "query architecture data");
				else
					printf("%s %i: \t%s: %i, %s: %i, %s: %i",
						"Adapter Node", FeatureDataArchitecture.NodeIndex, "TileBasedRenderer", FeatureDataArchitecture.TileBasedRenderer,
						"UMA", FeatureDataArchitecture.UMA, "CacheCoherentUMA", FeatureDataArchitecture.CacheCoherentUMA);

				//requires version 1703 build 10.0.15080
				//Skip on version 1507 (build 10240), version 1511 (build 10586), and version 1607 (build 14393)
				if (buildnumber > Win1607)
				{
					hr=pDevice->CheckFeatureSupport(D3D12_FEATURE_ARCHITECTURE1, &FeatureDataArchitecture1, sizeof(D3D12_FEATURE_DATA_ARCHITECTURE1));
					if (FAILED(hr))
						errorfailedto(hr, "query architecture 1 data");
					else		
						printf(", %s: %i", "IsolatedMMU", FeatureDataArchitecture1.IsolatedMMU);
				}

				puts("");

			}
		}// D3D12_FEATURE_ARCHITECTURE


		{//D3D12_FEATURE_SHADER_MODEL

			FeatureDataShaderModel.HighestShaderModel = D3D_SHADER_MODEL_6_0;

			hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_SHADER_MODEL, &FeatureDataShaderModel, sizeof(D3D12_FEATURE_DATA_SHADER_MODEL));

			//requires version 1607 build 10.0.14393
			//Skip on version 1507 (build 10240) and version 1511 (build 10586)

			if (buildnumber  >Win1511)
				{	
				if (FAILED(hr))
						errorfailedto(hr, "query maximum shader model");
				else
					switch (FeatureDataShaderModel.HighestShaderModel)
						{
						case D3D_SHADER_MODEL_5_1: pTier = "5_1";   break;
						case D3D_SHADER_MODEL_6_0: pTier = "6_0";   break;
							//Included yet undefined shader models just for gags
						case (D3D_SHADER_MODEL)0x61: pTier = "6_1";   break;
						case (D3D_SHADER_MODEL)0x70: pTier = "7_0";   break;
						default: pTier = "???";
						}
		
				printf("%s : %s%s (%#.4x)\n", "HighestShaderModel", "D3D12_SHADER_MODEL_", pTier, FeatureDataShaderModel.HighestShaderModel);
				}
		}//D3D12_FEATURE_SHADER_MODEL


		{//D3D12_FEATURE_DATA_D3D12_OPTIONS1
			hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS1, &FeatureDataOptions1, sizeof(D3D12_FEATURE_DATA_D3D12_OPTIONS1));

			//requires version 1511 build 10.0.10586
			//Skip on version 1507 (build 10240) or earlier

			if (buildnumber > Win1507)
				if (FAILED(hr))
					errorfailedto(hr, "query feature data 1");
				else
				{
					//print out option values

					printf("%s : %i\n", "WaveOps", FeatureDataOptions1.WaveOps);

					printf("%s : %i\n", "WaveLaneCountMin", FeatureDataOptions1.WaveLaneCountMin);

					printf("%s : %i\n", "WaveLaneCountMax", FeatureDataOptions1.WaveLaneCountMax);

					printf("%s : %i\n", "TotalLaneCount", FeatureDataOptions1.TotalLaneCount);

					printf("%s : %i\n", "ExpandedComputeResourceStates", FeatureDataOptions1.ExpandedComputeResourceStates);

					printf("%s : %i\n", "Int64ShaderOps", FeatureDataOptions1.Int64ShaderOps);
				}

		}//D3D12_FEATURE_D3D12_OPTIONS1

		
		{//D3D12_FEATURE_ROOT_SIGNATURE
			FeatureDataRootSignature.HighestVersion = D3D_ROOT_SIGNATURE_VERSION_1_1;

			hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_ROOT_SIGNATURE, &FeatureDataRootSignature, sizeof(D3D12_FEATURE_DATA_ROOT_SIGNATURE));

			//requires version 1607 build 10.0.14393
			//Skip on version 1507 (build 10240) and version 1511 (build 10586)

			if (buildnumber > Win1511)
				if (FAILED(hr))
					errorfailedto(hr, "query root signature version");
				else
				{
					switch (FeatureDataRootSignature.HighestVersion)
					{
					case D3D_ROOT_SIGNATURE_VERSION_1_0: pTier = "1_0";   break;
					case D3D_ROOT_SIGNATURE_VERSION_1_1: pTier = "1_1";   break;
					case (D3D_ROOT_SIGNATURE_VERSION)0x3: pTier = "1_2"; break;
					default: pTier = "???";
					}
					printf("%s : %s%s (%i)\n", "RootSignature.HighestVersion", "D3D_ROOT_SIGNATURE_VERSION_", pTier, FeatureDataRootSignature.HighestVersion);
				}
		}//D3D12_FEATURE_ROOT_SIGNATURE

			{//D3D12_FEATURE_DATA_D3D12_OPTIONS2
				hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS2, &FeatureDataOptions2, sizeof(D3D12_FEATURE_DATA_D3D12_OPTIONS2));
			
				//requires version 1703 build 10.0.15080
				//Skip on version 1507 (build 10240), version 1511 (build 10586), and version 1607 (build 14393)

			if (buildnumber > Win1607)
				if (FAILED(hr))
					errorfailedto(hr, "query feature data 2");
				else
				{
					//print out option values


					printf("%s : %i\n", "DepthBoundsTestSupported", FeatureDataOptions2.DepthBoundsTestSupported);

					switch (FeatureDataOptions2.ProgrammableSamplePositionsTier)
					{
					case D3D12_PROGRAMMABLE_SAMPLE_POSITIONS_TIER_NOT_SUPPORTED: pTier = "NOT_SUPPORTED"; break;
					case D3D12_PROGRAMMABLE_SAMPLE_POSITIONS_TIER_1:		pTier = "1"; break;
					case D3D12_PROGRAMMABLE_SAMPLE_POSITIONS_TIER_2:        pTier = "2"; break;
					default: pTier = "???";
					}
					printf("%s : %s%s (%i)\n", "ProgrammableSamplePositionsTier", "D3D12_PROGRAMMABLE_SAMPLE_POSITIONS_TIER_", pTier, FeatureDataOptions2.ProgrammableSamplePositionsTier);

				}

		}//D3D12_FEATURE_D3D12_OPTIONS2


		{//D3D12_FEATURE_SHADER_CACHE
		
			hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_SHADER_CACHE, &FeatureDataShaderCache, sizeof(D3D12_FEATURE_DATA_SHADER_CACHE));

			//requires version 1703 build 10.0.15080
			//Skip on version 1507 (build 10240), version 1511 (build 10586), and version 1607 (build 14393)

			if (buildnumber > Win1607)
				if (FAILED(hr))
					errorfailedto(hr, "query shader cache support");
				else
				{
					char* pTiers = new char[sizeof("SINGLE_PSO | LIBRARY | AUTOMATIC_INPROC_CACHE | AUTOMATIC_DISK_CACHE")]{};

					if (FeatureDataShaderCache.SupportFlags == D3D12_SHADER_CACHE_SUPPORT_NONE)
						pTiers = "NONE";
					else
					{
						const char delimiter[] = " | ";
						int numDelimiters = HammingWeight(FeatureDataShaderCache.SupportFlags) - 1;
						int count = 0;

					//	printf("%s: %i\n", "HammingWeight(FeatureDataShaderCache.SupportFlags)", HammingWeight(FeatureDataShaderCache.SupportFlags));
	

						if (FeatureDataShaderCache.SupportFlags &  D3D12_SHADER_CACHE_SUPPORT_SINGLE_PSO)
							{ pTiers = strncat(pTiers, "SINGLE_PSO", sizeof("SINGLE_PSO")); count++; if (count<=numDelimiters)  pTiers = strncat(pTiers, delimiter, sizeof(delimiter));	};
						if (FeatureDataShaderCache.SupportFlags &  D3D12_SHADER_CACHE_SUPPORT_LIBRARY)
							{ pTiers = strncat(pTiers, "LIBRARY", sizeof("LIBRARY")); count++; if (count <= numDelimiters) pTiers = strncat(pTiers, delimiter, sizeof(delimiter));  };
						if (FeatureDataShaderCache.SupportFlags &  D3D12_SHADER_CACHE_SUPPORT_AUTOMATIC_INPROC_CACHE)
							{ pTiers = strncat(pTiers, "AUTOMATIC_INPROC_CACHE", sizeof("AUTOMATIC_INPROC_CACHE"));  count++; if (count <= numDelimiters) pTiers = strncat(pTiers, delimiter, sizeof(delimiter)); 	};
						if (FeatureDataShaderCache.SupportFlags &  D3D12_SHADER_CACHE_SUPPORT_AUTOMATIC_DISK_CACHE)
							pTiers = strncat(pTiers, "AUTOMATIC_DISK_CACHE", sizeof("AUTOMATIC_DISK_CACHE"));
					};

				printf("%s : %s%s (%i)\n", "ShaderCache.SupportFlags", "D3D12_SHADER_CACHE_SUPPORT_", pTiers, FeatureDataShaderCache.SupportFlags);
				
				delete[] pTiers;
				}

		}//D3D12_FEATURE_SHADER_CACHE
				

		//DXGI_FORMAT
		if (CheckFormats)
		{
			puts("");

			for (UINT i = 0; i < ARRAYSIZE(Formats); i++)
			{
				//D3D12_FEATURE_FORMAT_SUPPORT
				FeatureDataFormatSupport.Format = Formats[i].id;

				hr = pDevice->CheckFeatureSupport(D3D12_FEATURE_FORMAT_SUPPORT, &FeatureDataFormatSupport, sizeof(D3D12_FEATURE_DATA_FORMAT_SUPPORT));

				printf("%s%s%s (%i):", "DXGI_FORMAT_", Formats[i].name, Formats[i].modifier, i);
				//if (FAILED(hr))
				//else

				if (VerboseFormats)
				{
					//Verbose output
					puts("");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_BUFFER) puts("Buffer (0x1)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_IA_VERTEX_BUFFER) puts("Vertex Buffer (0x2)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_IA_INDEX_BUFFER) puts("Index Buffer (0x4)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_SO_BUFFER) puts("Stream Output Buffer (0x8)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_TEXTURE1D) puts("Texture1D (0x10)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_TEXTURE2D) puts("Texture2D (0x20)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_TEXTURE1D) puts("Texture3D (0x40)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_TEXTURECUBE) puts("Cube Texture (0x80)");

					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_SHADER_LOAD) puts("Shader Load function (0x100)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_SHADER_SAMPLE) puts("Shader Sample function (0x200)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_SHADER_SAMPLE_COMPARISON) puts("Shader Sample comparison functions (0x400)");
					//reserved if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_SHADER_SAMPLE_MONO_TEXT); //"(0x800)"
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_MIP) puts("Mipmaps (0x1000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_RENDER_TARGET) puts("Render Target (0x4000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_BLENDABLE) puts("Blend ops (0x8000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_DEPTH_STENCIL) puts("Depth Stencil (0x10000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_MULTISAMPLE_RESOLVE) puts("Multisample resolve (0x40000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_DISPLAY) puts("Display format (0x80000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_CAST_WITHIN_BIT_LAYOUT) puts("No cast to other formats (0x100000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_MULTISAMPLE_RENDERTARGET) puts("Multisample Render Target (0x200000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_MULTISAMPLE_LOAD) puts("Multisample with shader Load function (0x400000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_SHADER_GATHER) puts("Shader Gather function (0x800000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_BACK_BUFFER_CAST) puts("Back Buffer Cast"  "(0x1000000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_TYPED_UNORDERED_ACCESS_VIEW) puts("UAV"  "(0x2000000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_SHADER_GATHER_COMPARISON) puts("Shader Gather comparison functions"  "(0x4000000)");
					//video overlay
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_DECODER_OUTPUT) puts("Decoder output (0x8000000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_VIDEO_PROCESSOR_OUTPUT) puts("Video processor output (0x10000000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_VIDEO_PROCESSOR_INPUT) puts("Video processor input (0x20000000)");
					if (FeatureDataFormatSupport.Support1 & D3D12_FORMAT_SUPPORT1_VIDEO_ENCODER) puts("Video encoder (0x40000000)");

					//Atomic ops
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_UAV_ATOMIC_ADD) puts("UAV atomic Add (0x1)");
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_UAV_ATOMIC_BITWISE_OPS) puts("UAV atomic bitwise ops (0x2)");
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_UAV_ATOMIC_COMPARE_STORE_OR_COMPARE_EXCHANGE) puts("UAV atomic Compare Store or Exchange (0x4)");
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_UAV_ATOMIC_EXCHANGE) puts("UAV atomic Exchange (0x8)");
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_UAV_ATOMIC_SIGNED_MIN_OR_MAX) puts("UAV atomic Min or Max (0x10)");
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_UAV_ATOMIC_UNSIGNED_MIN_OR_MAX) puts("UAV atomic unsigned Min or Max (0x20)");
					//typed UAV
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_UAV_TYPED_LOAD) puts("UAV typed Load (0x40)");
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_UAV_TYPED_STORE) puts("UAV typed Store (0x80)");

					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_OUTPUT_MERGER_LOGIC_OP) puts("Blend logic ops (0x100)");
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_TILED) puts("Tiled resource (0x200)");
					if (FeatureDataFormatSupport.Support2 & D3D12_FORMAT_SUPPORT2_MULTIPLANE_OVERLAY) puts("Multiplane overlay (0x4000)");

					if (FeatureDataFormatSupport.Support1 == D3D12_FORMAT_SUPPORT1_NONE && FeatureDataFormatSupport.Support2 == D3D12_FORMAT_SUPPORT2_NONE) puts("Not supported (0x00)");
					puts("");

				}//verbose output
				else
					if (FAILED(hr)) puts(" not supported"); else printf(" %.8x %.8x\n", FeatureDataFormatSupport.Support1, FeatureDataFormatSupport.Support2);

			} //D3D12_FEATURE_FORMAT_SUPPORT


		}//DXGI_FORMAT

		if (!VerboseFormats) puts("");

		pAdapter->Release();
		pDevice->Release();
		++AdapterCount;
	} //while EnumAdapters1

	pFactory->Release();

	if (LimitToDeviceId && !DeviceIdFound) puts("Device ID not found");
	if (LimitToVendorId && !VendorIdFound) puts("Vendor ID not found");

	//	time_t time;
	//	struct tm * date;
	//	time(&time);
	//	date = localtime(&time);

	SYSTEMTIME date;
	GetLocalTime(&date);
	printf("%s %.4d-%.2d-%.2d %.2d:%.2d:%.2d\n", "FINISHED running on", date.wYear, date.wMonth, date.wDay, date.wHour, date.wMinute, date.wSecond);
	if (!LimitToAdapter) printf("%i %s", AdapterCount, "display adapters enumerated\n\n");
	//system("PAUSE");

	return 0;
}


/* BUILD NOTES

0. Install Windows 10 Preview 10.0.15063 (rs2_release)
https://www.microsoft.com/en-us/software-download/windowsinsiderpreviewadvanced


1. Install Visual Studio Community 2017 
https://www.visualstudio.com/thank-you-downloading-visual-studio/?sku=Community&rel=15

or Visual Studio Community 2017.1 Preview
https://www.visualstudio.com/thank-you-downloading-visual-studio/?ch=preview&sku=Community&rel=15


2. Enable full-featured WARP12 renderer
Install
Graphics Tools 
under
Windows 10 Settings - System - Apps&Features - Manage optional features
Windows 10 Settings - Apps - Apps&Features - Manage optional features (Windows 10 version 1703)

http://blogs.windows.com/buildingapps/2015/07/29/its-time-to-upgrade-your-world-and-your-apps/
http://blogs.msdn.microsoft.com/visualstudio/2016/08/02/universal-windows-apps-targeting-windows-10-anniversary-sdk/
http://blogs.msdn.microsoft.com/chuckw/2016/08/02/windows-10-anniversary-update-sdk/


You can optionally download the standalone Windows 10 SDK Tools 10.0.14393.795
https://developer.microsoft.com/en-US/windows/downloads/windows-10-sdk

or Windows SDK Insider Preview (10.0.15063.0)
https://www.microsoft.com/en-us/software-download/windowsinsiderpreviewSDK


3. On client machines, install the VC++ redistributable package for x86:

Visual C++ Redistributable for Visual Studio 2017  x86
https://go.microsoft.com/fwlink/?LinkId=746571


4. Add these library names to Project - Properties - Linker - Input - Additional Dependencies

d3d12.lib d3d11.lib d3d9.lib dxgi.lib dxguid.lib


5. Disable precompiled headers:

Project - Properties - C/C++ - Precompiled Headers - Precompiled Header - Not using precompiled headers


6. To allow Windows version check, save the following XML code to a text file then add the file name to Project - Properties - Manifest Tool - Input and Output - Additional Manifest Files

D3D12CheckFeatureSupport.manifest

<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
<compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1">
<application>
<supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/>
</application>
</compatibility>
</assembly>


7. Select Project - Retarget solution - 10.0.15063.0 

Select Build - Configuration Manager - Active Solution Configuration - Active Solution Platform - Release/x86

Note that Project properties above have to be copied into each separate combination of Debug/Release configuration and platform architecture.

*/