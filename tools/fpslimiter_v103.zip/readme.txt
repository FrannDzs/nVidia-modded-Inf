===============
| FPS Limiter |
===============

This application allows to set a maximum framerate limit when playing and dynamically adjust it.

Features
--------

- Supports Vulkan, OpenGL, DirectX 9, DirectX 10, DirectX 11 and DirectX 12.
- High-precision timing (usually more accurate than the game's built-in limiter).
- In-game adjustments via keyboard shortcuts.
- Very lightweight and efficient.
- No installation / drivers / administrative privileges required. Just extract the files and run.
- Wide compatibility with overclocking tools and overlays.

Instructions
------------

- Edit the file 'fpslimiter.cfg' to set the initial limit. If the setting is missing or invalid default is 60.
- Run 'fpslimiter64.exe' to start the loader for 64-bit games, or 'fpslimiter32.exe' to start the loader for 32-bit games.
  It will enable the limit for any games launched while the window is active.
- Press Control+Page Up in-game to increase limit.
- Press Control+Page Down in-game to decrease limit.
